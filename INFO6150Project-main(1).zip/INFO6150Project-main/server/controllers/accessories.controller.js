const Accessories = require('../lib/models/accessories.model');
const Format = require('response-format');
const CONSTANTS = require('../lib/utils/constants');

exports.create = async(req, res) => {
    try {
        console.log("==================================================");
        // console.log(req.body.toString());
        // let data = req.body.data
        const data = Object.assign({}, req.body)

        console.log(data)

        let { title, description, price, type, image, discount } = data;
        console.log(title);

        if (!req.body.title) {
            return res.status(400).send({
                message: "Title can not be empty"
            });
        }

        const Access = new Accessories({
            title,
            description,
            price,
            type,
            image,
            price,
            discount
        });

        const result = await Access.save();

        if (result) {
            console.log("----result---" + result);
            res.send(Format.success(["Successfully Added"]));
        }

    } catch (e) {
        console.log("====================Error occured ", e);
        res.status(500).send(Format.internalError([e.message]));
    }

}

// Retrieve and return all notes from the database.
exports.findAll = async(req, res) => {
    try {
        let query = {}
        const result = await Accessories.find(query);
        if (result) {
            res.send(Format.success("", result));
        }
    } catch (e) {
        console.log("====================Error occured ", e);
        res.status(500).send(Format.internalError([e.message]));
    }

};

// Retrieve and return all notes from the database.
exports.findByType = async(req, res) => {
    try {
        let query = req.params;
        const result = await Accessories.find(query);
        if (result) {
            res.send(Format.success("", result));
        }
    } catch (e) {
        console.log("====================Error occured ", e);
        res.status(500).send(Format.internalError([e.message]));
    }

};


// Find a single note with a noteId
exports.findOne = async(req, res) => {
    try {
        let query = { _id: req.params._id }
        const result = await Accessories.findOne(query);
        if (result) {
            res.send(Format.success("", result));
        }
    } catch (e) {
        console.log("====================Error occured ", e);
        res.status(500).send(Format.internalError([e.message]));
    }
};

// Update a note identified by the noteId in the request
exports.update = async(req, res) => {
    try {
        console.log("body ", req.body);
        console.log("params ", req.params);
        let query = { _id: req.params._id };
        let dataToUpdate = req.body;
        const result = await Accessories.update(query, dataToUpdate);
        if (result) {
            console.log("----result---" + result);
            res.send(Format.success(["Successfully Updated"]));
        }
    } catch (e) {
        console.log("====================Error occured ", e);
        res.status(500).send(Format.internalError([e.message]));
    }
};

// Delete a note with the specified noteId in the request
exports.delete = async(req, res) => {
    try {

        console.log("body ", req.body);
        console.log("query ", req.query);
        console.log("params ", req.params);
        let query = {
            _id: req.params._id
        };
        const result = await Accessories.findByIdAndDelete(query);
        if (result) {
            console.log("----result---" + result);
            res.send(Format.success(["Successfully Deleted"]));
        }
    } catch (e) {
        console.log("====================Error occured ", e);
        res.status(500).send(Format.internalError([e.message]));
    }
};