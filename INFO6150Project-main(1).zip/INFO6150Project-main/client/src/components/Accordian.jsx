import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';

const styles = theme => ({
  root: {
    width: '90%',
    paddingLeft: 70,
    
    margin: '1%'
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },
});

function SimpleExpansionPanel(props) {
  const { classes } = props;
  return (
    <div className={classes.root}>
      <ExpansionPanel>
        <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
          <Typography className={classes.heading}>Fitness</Typography>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
          <Typography>
          Fitness is defined as the quality or state of being fit and healthy.Around 1950, perhaps consistent with 
          the Industrial Revolution and the treatise of World War II, the term "fitness" increased in western vernacular
           by a factor of ten.The modern definition of fitness describes either a person or machine's ability to perform 
           a specific function or a holistic definition of human adaptability to cope with various situations. 
           This has led to an interrelation of human fitness and attractiveness that has mobilized global fitness and fitness equipment industries. 
           Regarding specific function, fitness is attributed to persons who possess significant aerobic or anaerobic ability, i.e. endurance or strength. 
           A well-rounded fitness program improves a person in all aspects of fitness compared to practicing only one, such as only cardio/respiratory endurance or only weight training.
          </Typography>
        </ExpansionPanelDetails>
      </ExpansionPanel>
      <ExpansionPanel>
        <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
          <Typography className={classes.heading}>Yoga</Typography>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
          <Typography>
          Yoga gurus from India later introduced yoga to the West,following the success of Swami Vivekananda in the late 19th 
          and early 20th century with his adaptation of yoga tradition, excluding asanas. Outside India, it has developed into 
          a posture-based physical fitness, stress-relief and relaxation technique.Yoga in Indian traditions, however, is more 
          than physical exercise; it has a meditative and spiritual core.One of the six major orthodox schools of Indian philosophy 
          is also called Yoga, which has its own epistemology, ontology and metaphysics, and is closely related to Samkhya philosophy. 
          LiveFit focuses on all aspects of yoga.
          </Typography>
        </ExpansionPanelDetails>
      </ExpansionPanel>
      <ExpansionPanel>
        <ExpansionPanelSummary expandIcon={<ExpandMoreIcon />}>
          <Typography className={classes.heading}>Healthy Food</Typography>
        </ExpansionPanelSummary>
        <ExpansionPanelDetails>
          <Typography>
          A healthy diet may contain fruits, vegetables, and whole grains, and includes little to no processed food and sweetened beverages. 
          The requirements for a healthy diet can be met from a variety of plant-based and animal-based foods, although a non-animal source of 
          vitamin B12 is needed for those following a vegan diet.Various nutrition guides are published by medical and governmental 
          institutions to educate individuals on what they should be eating to be healthy. Nutrition facts labels are also mandatory in 
          some countries to allow consumers to choose between foods based on the components relevant to health.
          </Typography>
        </ExpansionPanelDetails>
      </ExpansionPanel>
    </div>
  );
}

SimpleExpansionPanel.propTypes = {
  classes: PropTypes.object.isRequired,
};

export default withStyles(styles)(SimpleExpansionPanel);