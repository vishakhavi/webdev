import './App.css';

import Menu from '@material-ui/core/Menu';
// import Header from "./components/Header"
import MyCarousel from "./components/carousal"
import ShowCard from "./components/Cards"
import Jumbotron from './components/Jumbotron';
import Accordian from './components/Accordian'
import GridCard from './components/gridCard'
import Footer from './components/Footer';
import {useState, useEffect} from 'react';

import LoginForm from './components/LoginForm/LoginForm';
import RegistrationForm from './components/RegistrationForm/RegistrationForm';
import Home from './components/Home/Home';
import PrivateRoute from './utils/PrivateRoute';
import {
  BrowserRouter,
  Switch,
  Route,
  Redirect,
  Link
} from "react-router-dom";

import AlertComponent from './components/AlertComponent/AlertComponent';
import AdminHome from './components/Admin/AdminHome';
import AccessoriesShowCase from './components/Accessories/AccessoriesShowCase';
import AccessoriesList from './components/Accessories/AccessoriesList';
import ProductDetails from './components/Accessories/ProductDetails';
import PageNotFound from './components/NotFound/PageNotFound';
import Header from './components/Header';
import HomePage from './components/HomePage';
import OrdersHistory from './components/OrdersHistory/OrdersHistory';
import Appointments from './components/appointments';
import Diet_Appointment from './components/diet_appointment';
import Aerobics_Appointment from './components/aerobics_appointment';
import Exercises_Appointment from './components/exercises_appointment';
import Body_Appointment from './components/body_appointment';
import {withRouter} from 'react-router'
import Logout from './components/Logout/Logout'
import Terms from './components/TermsAndConditionsForm/Terms';
import Privacy from './components/PrivacyForm/Privacy';

function App() {


  const [title, updateTitle] = useState(null);
  const [errorMessage, updateErrorMessage] = useState(null);

  return (
    <BrowserRouter >
      <div className="App">
      
      <div style={{ margin: '2em', padding: '10px' }}> </div>
          <div className="">
            <Switch>
              <Route exact path="/" >
                <Header/>
                <HomePage/>
                <Footer/>
              </Route>
              <PrivateRoute path="/accessories/type/:type">
                <Header/>
                <AccessoriesList/>
                <Footer/>
              </PrivateRoute>
              <PrivateRoute path="/accessories/:id">
                <Header/>
                <ProductDetails/>
                <Footer/>
              </PrivateRoute>
              <Route exact path="/terms">
              <Header/>
                <Terms/>
                <Footer/>
              </Route>
              <Route exact path="/privacy">
              <Header/>
                <Privacy/>
                <Footer/>
              </Route>
              <PrivateRoute exact path="/accessories" >
                <Header/>
                <AccessoriesShowCase/>
                <Footer/>
              </PrivateRoute> 
              
              <Route path="/register">
                <RegistrationForm showError={updateErrorMessage} updateTitle={updateTitle}/>
              </Route>
              <Route path="/login">
                <LoginForm showError={updateErrorMessage} updateTitle={updateTitle}/>
              </Route>
              <Route path="/logout">
                <Logout />
              </Route>
              <Route path="/admin">
                <AdminHome />
              </Route>
              <Route path="/notfound">
                <PageNotFound />
              </Route>
              <PrivateRoute exact path="/history">
                <Header/>
                  <OrdersHistory />
                <Footer/>
              </PrivateRoute>
              <PrivateRoute exact path="/appointments">
                <Header/>
                <Appointments />
                <Footer/>
              </PrivateRoute>
              <Route path="/diet_appointment">
              <Header/>
                <Diet_Appointment />
                <Footer/>
              </Route>
              <Route path="/aerobics_appointment">
              <Header/>
                <Aerobics_Appointment />
                <Footer/>
              </Route>
              <Route path="/exercises_appointment">
              <Header/>
                <Exercises_Appointment />
                <Footer/>
              </Route>
              <Route path="/body_appointment">
              <Header/>
                <Body_Appointment />
                <Footer/>
              </Route>
              <Route path="/terms">
              <Header/>
                <Body_Appointment />
                <Footer/>
              </Route>
              <Route path="/privacy">
              <Header/>
                <Body_Appointment />
                <Footer/>
              </Route>
              <Route render={() => <Redirect to={{pathname: "/notfound"}} />} />
            </Switch>
            <AlertComponent errorMessage={errorMessage} hideError={updateErrorMessage}/>
          </div>
          
      </div>
    </BrowserRouter>

  );
}

export default App;
