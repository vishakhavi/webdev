import React, { useCallback, useEffect, useState } from 'react'
import { DataGrid ,GridToolbar} from '@material-ui/data-grid';
import axios from 'axios';
import Fab from '@material-ui/core/Fab';
import AddIcon from '@material-ui/icons/Add';
import {
  Link,
  useHistory
} from "react-router-dom";



export default function AccessoryList() {
    useEffect(()=>{
      getDetails();
    },[]);

    const history = useHistory();

    const [products,setProducts] = useState([]);

    const columns = [
        { field: 'id', headerName: 'ID', sortable: false,width: 70 },
        { field: 'title', headerName: 'Title', sortable: false,width: 130 },
        { field: 'rating', headerName: 'Rating',sortable: false, type: 'number',width: 130 },
        { field: 'description',headerName: 'Description', sortable: false,width: 130,},
        { field: 'price', headerName: 'Price', type: 'number', sortable: false, width: 130},
        { field: 'type', headerName: 'Type', sortable: false, width: 130},
        { field: 'discount', headerName: 'Discount', type: 'number', sortable: false, width: 130},
        { field: 'status', headerName: 'Status', sortable: false, width: 130},
      ];

      const getDetails = async() => {
        let { data } = await axios.get(`/admin/accessories`);
        data = data.data;
        let count = 0;
        data.map(el => el["id"] = ++count);
        setProducts(data);
        console.log(data);
      }

      const getCellActions = useCallback((param) => history.push(`/admin/product/${param.data._id}`), [history]);
   

    return (
        <div className="wrapper" >
          <h2>Products List</h2>
          <div className="action-btn">
            <Link exact to="/admin/product-add">
              <Fab color="primary" aria-label="add">
                <AddIcon />
              </Fab>
            </Link>
          </div>
            
          <DataGrid  onRowSelected={getCellActions}
              rows={products} columns={columns} pageSize={10} localeText={{
            toolbarDensity: 'Size',
            toolbarDensityLabel: 'Size',
            toolbarDensityCompact: 'Small',
            toolbarDensityStandard: 'Medium',
            toolbarDensityComfortable: 'Large',
          }}
          components={{
            Toolbar: GridToolbar,
          }}/>
        </div>
    )
}
