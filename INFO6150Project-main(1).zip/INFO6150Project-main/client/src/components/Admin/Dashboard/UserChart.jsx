import React from 'react'
import { Line } from 'react-chartjs-2';




export default function UserChart(props) {
  const data = {
    datasets: [
      {
        label: props.label,
        data: props.data,
        fill: false,
        backgroundColor: props.backgroundColor,
        borderColor: props.borderColor,
      },
    ],
  };
  
  const options = {
    scales: {
      xAxes: [{
        type: 'linear',
        scaleLabel: {
          display: true,
          labelString: 'Month'
        }
      }],
      yAxes: [
        {
          // scaleLabel: {
          //   display: true,
          //   labelString: 'Month'
          // },
          // gridLines: {
          //   display: false
          // },
          autoSkip:false,
          ticks: {
            // min: 0,
            stepSize: 2,
            autoSkip:false
            // max: 10,
            // beginAtZero: true,
            // callback: function(value) {if (value % 1 === 0) {return value;}}
          },
        },
      ],
    },
  };

    return (
        <div style={{
            height: '300px'
          }}>
            <Line data={data} options={options} />
        </div>
    )
}
