import React, { useEffect } from 'react'
import './Products.css';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import ShoppingCartOutlinedIcon from '@material-ui/icons/ShoppingCartOutlined';
import Rating from '@material-ui/lab/Rating';
import FavoriteIcon from '@material-ui/icons/Favorite';
import { withStyles } from '@material-ui/core/styles';
import { useSelector, useDispatch } from 'react-redux';
import { Link,useHistory } from "react-router-dom";
import {addToCart as addToCartAction} from '../../redux/actions/cartActions';
import {useState} from 'react';
import {getProductDetails} from '../../redux/actions/productActions'
import {withSnackbar} from '../../utils/snackbar';
import VisibilityIcon from '@material-ui/icons/Visibility';
import { NavLink } from 'reactstrap';

const AccessoriesCard = (props) => {
    const history = useHistory();

    const cart = useSelector(state => state.cart);

    const { cartItems } = cart;

    useEffect(()=>{
        let item = cartItems.find(el => el.product === props.payload._id);
        if(item)setQty(item.qty);
    },[cartItems,props]);

    // const [showSnackBar,setShowSnackBar] = useState(false);

    let [qty,setQty] = useState(0);

    const dispatch = useDispatch();

    const StyledRating = withStyles({
        iconFilled: {
          color: '#ff6d75',
        }
      })(Rating);

    const addToCart = () => {
        setQty(++qty);
        props.snackbarShowMessage(`Item added`);
        dispatch(addToCartAction(props.payload._id,qty))
    }

    const currentProduct = () =>{

        dispatch(getProductDetails(props.payload._id));
        history.push('/accessories/'+props.payload._id);
    }


    return (
        <div className="card-wrapper">
                <Card >
                    <CardContent className="card-content">
                        {props?.payload?.image != null ? <img  className="card-img" src={props?.payload?.image} alt="products"/>:
                            <img  className="card-img"  src="/images/placeholder-image.png" alt="products"/>
                        }
                        <Typography  color="textPrimary">
                        {props.payload.title}
                        </Typography>
                        <Typography  color="textSecondary">
                        {props.payload.description}
                        </Typography>
                        <StyledRating
                            name="customized-color"
                            defaultValue={props?.payload?.rating}
                            readOnly
                            size="small"
                            precision={1}
                            icon={<FavoriteIcon fontSize="inherit" />}/>
                    </CardContent>
                    <CardActions>
                    <Typography variant="body2" component="p" className="price-info">
                            <Typography variant="h6" component="span" className="s-span">
                                    ${props?.payload?.price - (props?.payload?.price * props?.payload?.discount /100) || 0}
                                </Typography>
                                <Typography variant="body2" component="span" className="o-span">
                                ${props?.payload?.price}
                            </Typography>
                            <Typography variant="body2" component="span" className="discount-span">
                                {props?.payload?.discount > 0 ? props?.payload?.discount + "% Off":''}
                            </Typography>
                        </Typography>
                    {/* <Link to={`/accessories/${props.payload._id}`} className="btn-link"> */}
                        <Button size="small" variant="contained"
                            color="secondary"
                            onClick={currentProduct}
                            startIcon={<VisibilityIcon />}>
                                View</Button>
                        {/* </Link> */}
                        <Button size="small" variant="contained"
                            color="secondary"
                            onClick={addToCart}
                            startIcon={<ShoppingCartOutlinedIcon fontSize="large" style={{color:'white'}}/>}>
                                Add</Button>
                    </CardActions>
                </Card>
        </div>
    )
}


export default withSnackbar(AccessoriesCard);