import React from 'react'
import SideBar from './SideBar';
import './Admin.css';

const AdminHome = () => {
    return (
        <div>
            <SideBar/>
        </div>
    )
}


export default AdminHome;
