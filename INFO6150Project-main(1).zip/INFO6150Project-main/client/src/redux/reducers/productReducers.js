import * as actionTypes from '../constants/products';

const INITIAL_STATE = {
    loading: true,
    products: []
}

const INITIAL_TYPE_STATE = {
    loading: true,
    products: []
}

const INITIAL_DETAILS_STATE = {
    loading: true,
    product: {}
}

export const getProductsReducer = (state = INITIAL_STATE, action) => {
    switch (action.type) {

        case actionTypes.GET_PRODUCTS_REQUEST:
            return {
                loading: true,
                products: [],
            }
        case actionTypes.GET_PRODUCTS_SUCCESS:
            return {
                loading: false,
                products: action.payload,
            }
        case actionTypes.GET_PRODUCTS_FAIL:
            return {
                loading: false,
                products: action.payload,
            }
        default:
            return state;
    }
}

export const getProductsByTypeReducer = (state = INITIAL_TYPE_STATE, action) => {
    switch (action.type) {

        case actionTypes.GET_PRODUCTS_BY_TYPE_REQUEST:
            return {
                loading: true,
                products: [],
            }
        case actionTypes.GET_PRODUCT_BY_TYPE_SUCCESS:
            return {
                loading: false,
                products: action.payload,
            }
        case actionTypes.GET_PRODUCT_BY_TYPE_FAIL:
            return {
                loading: false,
                products: action.payload,
            }
        default:
            return state;
    }
}


export const getProductDetailsReducer = (state = INITIAL_DETAILS_STATE, action) => {
    switch (action.type) {

        case actionTypes.GET_PRODUCT_DETAILS_REQUEST:
            return {
                loading: true,
            }
        case actionTypes.GET_PRODUCT_DETAILS_SUCCESS:
            return {
                loading: false,
                product: action.payload,
            }
        case actionTypes.GET_PRODUCT_DETAILS_FAIL:
            return {
                loading: false,
                product: action.payload,
            }
        case actionTypes.GET_PRODUCT_DETAILS_RESET:
            return {
                product: {},
            }
        default:
            return state;
    }
}