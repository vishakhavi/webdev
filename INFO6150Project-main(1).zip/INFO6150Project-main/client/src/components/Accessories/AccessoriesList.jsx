import React, { useEffect, useState } from 'react'
import AccessoriesCard from './AccessoriesCard';
import { useParams, withRouter } from "react-router";
import { getProductsByType } from '../../redux/actions/productActions';
import { useDispatch, useSelector } from 'react-redux';
import ProductSkeleton from './ProductSkeleton';

const AccessoriesList = (props) => {

    let {type} = useParams();
    const [productType] = useState(type);
    const dispatch = useDispatch();

    useEffect(()=>{
        dispatch(getProductsByType(productType));
    },[productType,dispatch]);
    
    const getProducts = useSelector((state)=> state.getProductsByType);
    const {products, loading, error} = getProducts;
    const navigateToDetails = (id) =>{
        props.history.push('/accessories/'+id);
    }

    const navigateToType = (type) =>{
        props.history.push('/accessories/type'+type);
    }
    const getList = () => {
            let cardList = [];
            products.map((el) => cardList.push(<AccessoriesCard key={el?._id} payload={el}
                navigateToDetails={(id) => navigateToDetails(id)}/>));
            return cardList;
    }
   
    return (
        <div>
            <h1>{type}</h1>
            <div>
                { loading ? (<ProductSkeleton/>) : error ? (<h1>Error</h1>) : getList()}
            </div>
            <div className="page-wrapper">
            </div>
        </div>
    )
}

export default withRouter(AccessoriesList) 
