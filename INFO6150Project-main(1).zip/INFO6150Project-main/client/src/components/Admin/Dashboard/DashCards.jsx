import React from 'react'
import { makeStyles } from '@material-ui/core/styles';
import './Dash.css';
import Card from '@material-ui/core/Card';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';

const useStyles = makeStyles(() => ({

    paper: {
      height: 140,
      width: 300
    },
    pos:{
        textAlign:"left"
    },
    icons:{
        textAlign:"right"
    }
  }));

export default function DashCards(props) {
    const { backgroundColor ,value,title ,icon} = props;
    const classes = useStyles();
    // classes.paper.backgroundColor = "antiquewhite";
    return (
        <div>
            <Card className={classes.root} style={{backgroundColor}}>
                <CardContent >
                    
                    <Typography variant="h3" gutterBottom>
                    {value}
                    </Typography>
                    {/* <div >  */}
                        {/* {icon}     */}
                    {/* </div> */}
                    
                    <Typography className={classes.pos} variant="h6" color="textSecondary">
                    {title}
                    </Typography>
                </CardContent>
            
            </Card>
        </div>
    )
}
