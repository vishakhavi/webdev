import * as actionTypes from '../constants/products';
import axios from 'axios';


export const getProducts = () => async(dispatch) => {
    try {

        const { data } = await axios.get('/accessories');
        dispatch({
            type: actionTypes.GET_PRODUCTS_SUCCESS,
            payload: data.data
        })
    } catch (error) {
        dispatch({
            type: actionTypes.GET_PRODUCTS_FAIL,
            payload: error.response && error.response.data.message ?
                error.response.data.message : error.message
        })
    }
}


export const getProductDetails = (id) => async(dispatch) => {
    try {
        const { data } = await axios.get(`/accessories/${id}`);
        dispatch({
            type: actionTypes.GET_PRODUCT_DETAILS_SUCCESS,
            payload: data.data
        })
    } catch (error) {
        dispatch({
            type: actionTypes.GET_PRODUCT_DETAILS_FAIL,
            payload: error.response && error.response.data.message ?
                error.response.data.message : error.message
        })
    }
}

export const getProductsByType = (type) => async(dispatch) => {
    try {
        const { data } = await axios.get(`/accessories/type/${type}`);
        dispatch({
            type: actionTypes.GET_PRODUCT_BY_TYPE_SUCCESS,
            payload: data.data
        })
    } catch (error) {
        dispatch({
            type: actionTypes.GET_PRODUCT_BY_TYPE_FAIL,
            payload: error.response && error.response.data.message ?
                error.response.data.message : error.message
        })
    }
}


export const removeProductDetails = (id) => async(dispatch) => {
    dispatch({
        type: actionTypes.GET_PRODUCT_DETAILS_RESET
    })
}