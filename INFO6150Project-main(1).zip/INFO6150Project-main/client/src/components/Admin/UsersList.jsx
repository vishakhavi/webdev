import React, { useEffect, useState } from 'react'
import { DataGrid ,GridToolbar} from '@material-ui/data-grid';
import axios from 'axios';

import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';
import Button from '@material-ui/core/Button';
import { withSnackbar } from '../../utils/snackbar';


const UserList = (props) => {
    useEffect(()=>{
      getDetails();
    },[]);

    const [openModal, setOpenModal] = React.useState(false);

    const [status,setStatus] = React.useState(null);

    let [currentId,setId] = React.useState(null);
  
    const handleYes = async() => {
      if(currentId == null) return;
      let newStatus;
      if(status === "ACTIVE"){ newStatus =  "INACTIVE"}
      else{ newStatus = "ACTIVE"}
      let { data } = await axios.patch(`admin/users/${currentId}`,{status:newStatus});
      data = data.data;
      console.log(data);
      
      handleClose();
      getDetails();
      props.snackbarShowMessage(`Successfully Updated`);
    }
  
    const handleClose = () => {
      setOpenModal(false);
      setId(null);
      setStatus(null);
    };

    const [users,setUsers] = useState([]);

    const columns = [
        { field: 'id', headerName: 'ID', sortable: false },
        { field: 'name', headerName: 'Name', sortable: false },
        { field: 'email', headerName: 'Email Id',sortable: false, type: 'email',width: 130 },
        { field: 'status',headerName: 'Status', sortable: false}
      ];

      const getDetails = async() => {
        let { data } = await axios.get(`users`);
        data = data.data;
        let count = 0;
        data.map(el => el["id"] = ++count);
        setUsers(data);
      }

      const getCellActions = (params) => {
        setStatus(params.data.status);
        setId(params.data._id);
        console.log(currentId);
        setOpenModal(true);
      }
   

    return (
        <div className="wrapper" >
          <h2>Users List</h2>
            
          <DataGrid  onRowSelected={getCellActions}
              rows={users} columns={columns} pageSize={10} localeText={{
            toolbarDensity: 'Size',
            toolbarDensityLabel: 'Size',
            toolbarDensityCompact: 'Small',
            toolbarDensityStandard: 'Medium',
            toolbarDensityComfortable: 'Large',
          }}
          components={{
            Toolbar: GridToolbar,
          }}/>

          <Dialog
                open={openModal}
                onClose={handleClose}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title">{"Status"}</DialogTitle>
                <DialogContent>
                <DialogContentText id="alert-dialog-description">
                    Do you want to change status to {status == "ACTIVE" ? "INACTIVE" :"ACTIVE"} ?
                </DialogContentText>
                </DialogContent>
                <DialogActions>
                <Button onClick={handleClose} color="primary">
                    Cancel
                </Button>
                <Button onClick={handleYes} color="primary" autoFocus>
                    Yes
                </Button>
                </DialogActions>
            </Dialog>
        </div>
    )
}


export default withSnackbar(UserList);