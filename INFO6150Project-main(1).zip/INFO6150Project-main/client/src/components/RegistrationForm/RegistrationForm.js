import React, {useState} from 'react';
import './RegistrationForm.css';
import axios from 'axios';
import {API_BASE_URL, ACCESS_TOKEN_NAME} from '../../constants/apiContants';
import { withRouter } from "react-router-dom";
import ReCAPTCHA from "react-google-recaptcha";

function RegistrationForm(props) {
    const [state , setState] = useState({
        name:"",
        email : "",
        password : "",
        confirmPassword: "",
        successMessage: null
    })
    const handleChange = (e) => {
        const {id , value} = e.target   
        setState(prevState => ({
            ...prevState,
            [id] : value
        }))
    }

    const [btn,setBtnEnable] = useState(true);

    const key = "6LdkZ6QUAAAAAPBmfE5yBKmYsEKGTanHQRdYrQqZ";
    const sendDetailsToServer = () => {
        if(state.email.length && state.password.length && state.name.length) {
            props.showError(null);
            const payload={
                "name":state.name,
                "email":state.email,
                "password":state.password,
            }
            
            axios.post(API_BASE_URL+'/user/register', payload)
                .then((response) => {
                    if(response.status === 200 && response.data.token != null){
                        setState(prevState => ({
                            ...prevState,
                            'successMessage' : 'Registration successful. Redirecting to home page..'
                        }))
                        localStorage.setItem(ACCESS_TOKEN_NAME,response.data.token);
                        redirectToHome();
                        props.showError(null)
                    }else if(response.status === 200 && response.data.msg === "User Already Exists"){
                        props.showError("Email address already exists. Please login");
                        alert("Email address already exists. Please login");
                    } else{
                        props.showError("Some error ocurred");
                        alert("Some error ocurred");
                    }
                })
                .catch(function (error) {
                    console.log(error);
                });    
        } else if(state.name.length == 0){
            alert('Please enter Name');
        } else {
            props.showError('Please enter valid username and password')    
            alert('Please enter valid username and password');
        }
    }
    const redirectToHome = () => {
        props.updateTitle('Home')
        props.history.push('/');
    }
    const redirectToLogin = () => {
        props.updateTitle('Login')
        props.history.push('/login'); 
    }
    const handleSubmitClick = (e) => {
        e.preventDefault();
        const re = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if(re.test(String(state.email).toLowerCase())) { 
            if(state.password === state.confirmPassword){
                sendDetailsToServer()
            }
            else{
                alert('Passwords do not match');
                props.showError('Passwords do not match');
            }
        } else {
            alert('Enter valid Email address');
            props.showError('Enter valid Email address');
        }
    }

    const onCaptchaChange = (e) => {
        console.log(e);
        setBtnEnable(false);
    }


    return(
        <div >
            <p className="head" align="center">Welcome to LiveFit!</p>
            <div className="main">
            <p className="sign" align="center">Register</p>
            <form>
                <center>
                <div>
                    <label htmlFor="exampleInputEmail1">Name</label>
                    <br></br>
                    <input type="text" 
                        className="un " 
                        align="center"
                        id="name" 
                        placeholder="Enter Name" 
                        value={state.name}
                        onChange={handleChange}
                    />
                </div>
                <div>
                <label htmlFor="exampleInputEmail1">Email address</label>
                <br></br>
                <input type="email" 
                       className="un " 
                       align="center"
                       id="email" 
                       aria-describedby="emailHelp" 
                       placeholder="Enter email" 
                       value={state.email}
                       onChange={handleChange}
                />
                </div>

                <div >
                    <label htmlFor="exampleInputPassword1">Password</label>
                    <br></br>
                    <input type="password" 
                        className="pass" 
                        id="password" 
                        placeholder="Password"
                        value={state.password}
                        onChange={handleChange} 
                    />
                </div>
                <div>
                    <label htmlFor="exampleInputPassword1">Confirm Password</label>
                    <br></br>
                    <input type="password" 
                        className="pass" 
                        id="confirmPassword" 
                        placeholder="Confirm Password"
                        value={state.confirmPassword}
                        onChange={handleChange} 
                    />
                </div>
                <div>
                <ReCAPTCHA
                    sitekey={key}
                    onChange={onCaptchaChange}
                />
                </div>
                <button 
                    type="submit" 
                    className="button"
                    onClick={handleSubmitClick}
                    disabled = {btn}
                >
                    Register
                </button>
                </center>
            </form>
            <div className="alert alert-success mt-2" style={{display: state.successMessage ? 'block' : 'none' }} role="alert">
                {state.successMessage}
            </div>
            <div className="mt-2">
                <center>
                <span>Already have an account? </span>
                <span className="loginText" onClick={() => redirectToLogin()}>Login here</span> 
                </center>
            </div>
            </div>
        </div>
    )
}

export default withRouter(RegistrationForm);