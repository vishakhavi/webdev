const User = require("../lib/models/User");
const Format = require('response-format');
const { check, validationResult } = require("express-validator/check");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

exports.test = function(req, res) {
    res.header("Access-Control-Allow-Origin", "*");
    res.send('Greetings from the test controller!!');
};

exports.user_create = async function(req, res) {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return res.status(400).json({
            errors: errors.array()
        });
    }

    const {
        email,
        password,
        name,
        status
    } = req.body;
    try {
        let user = await User.findOne({
            email
        });
        if (user) {
            return res.status(200).json({
                msg: "User Already Exists"
            });
        }

        user = new User({
            email,
            password,
            name,
            status
        });

        const salt = await bcrypt.genSalt(10);
        user.password = await bcrypt.hash(password, salt);

        await user.save();

        const payload = {
            user: {
                id: user.id
            }
        };

        jwt.sign(
            payload,
            "randomString", {
                expiresIn: 10000
            },
            (err, token) => {
                if (err) throw err;
                res.status(200).json({
                    token
                });
            }
        );
    } catch (err) {
        console.log(err.message);
        res.status(500).send("Error in Saving");
    }
};

exports.user_login = async function(req, res) {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
        return res.status(400).json({
            errors: errors.array()
        });
    }

    const { email, password } = req.body;
    try {
        let user = await User.findOne({
            email
        });
        
        if (user == null)
            return res.status(200).json({
                message: "User Not Exist"
            });

        if (user.status != "ACTIVE")
            return res.status(200).json({
                message: "User is Inactive"
            });

            if(user.type == "ADMIN"){
                const isMatch = await bcrypt.compare(password, user.password);
                if (!isMatch)
                return res.status(200).json({
                    message: "Incorrect Password!"
                });
                const payload = {
                    user: {
                        id: user.id
                    }
                };
        
                jwt.sign(
                    payload,
                    "randomString", {
                        expiresIn: 3600
                    },
                    (err, token) => {
                        if (err) throw err;
                        res.status(200).json({
                            token,
                            message: "ADMIN"
                        });
                    }
                );
            }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch)
            return res.status(200).json({
                message: "Incorrect Password!"
            });

        const payload = {
            user: {
                id: user.id
            }
        };

        jwt.sign(
            payload,
            "randomString", {
                expiresIn: 3600
            },
            (err, token) => {
                if (err) throw err;
                res.status(200).json({
                    token,
                    data:{_id:user.id,name:user.name,type:user.type}
                });
            }
        );
    } catch (e) {
        console.error(e);
        res.status(500).json({
            message: "Server Error"
        });
    }
}

exports.me = async function(req, res) {
    try {
        // request.user is getting fetched from Middleware after token authentication
        const user = await User.findById(req.user.id);
        let { name, status, type, email } = user;
        res.json({ "response": "success", data: { name, status, type, email } });
    } catch (e) {
        res.send({ message: "Error in Fetching user" });
    }
}

exports.findAll = async(req, res) => {
    try {
        let query = { "type": { $ne: "ADMIN" } }
        const result = await User.find(query);
        if (result) {
            res.send(Format.success("", result));
        }
    } catch (e) {
        res.status(500).send(Format.internalError([e.message]));
    }

};

// Update a note identified by the noteId in the request
exports.update = async(req, res) => {
    try {
        let query = { _id: req.params._id };
        let dataToUpdate = {
            status: req.body.status
        }

        const result = await User.updateOne(query, dataToUpdate);
        if (result) {
            res.send(Format.success(["Successfully Updated"]));
        }
    } catch (e) {
        console.log("====================Error occured ", e);
        res.status(500).send(Format.internalError([e.message]));
    }
};