import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import ButtonBase from '@material-ui/core/ButtonBase';
import dumpbell from "../images/jumbtronlivefit.jpg"

const useStyles = makeStyles((theme) => ({
  root: {
   // flexGrow: 1,
   paddingLeft: 60,
    margin: 20,
  },
  paper: {
    padding: 10,
    margin: 10,
    maxWidth: 1450,
    justifyContent: 'center'
  },
  image: {
    width: 800,
    paddingTop: 5
   

  },
  img: {
    margin: 10,
    display: 'block',
    maxWidth: '100%',
    maxHeight: '100%',
    
  },
}));

export default function Jumbotron() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <Paper className={classes.paper}>
        <Grid container >
          
          <Grid item  container spacing={5}>
            <Grid item xs container direction="row" spacing={7} >
              <Grid item xs className={classes.image}>
              <img className={classes.img} alt="complex" src={dumpbell} />
              </Grid>
             
            </Grid>
   
            <Grid item xs container direction="row" spacing={4}>
              <Grid item xs>
                <Typography gutterBottom variant="h3" fontSize="30">
                For the ease of Fit.
                </Typography>
                <Typography variant="h6" gutterBottom>
                At LiveFit, we strive to keep you fit & healthy through a range of holistic offerings that include fitness and yoga, healthy meals, mental wellbeing and primary care. Now anyone can stay healthy from the safety of their homes with just a single app that helps you to be better each day.
                </Typography>
               
              </Grid>
             
            </Grid>
            
          </Grid>
        </Grid>
      </Paper>
    </div>
  );
}
