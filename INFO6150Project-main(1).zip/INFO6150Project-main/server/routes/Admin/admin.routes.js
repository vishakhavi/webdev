module.exports = (app) => {

    const accessories = require('../../controllers/accessories.controller');
    const users = require('../../controllers/user.controller');
    const admin = require('../../controllers/admin.controller');
    const ADMIN = '/admin';

    app.get('/', function(req, res, next) {
        res.send('accessories');
    });

    // Create a new Note
    app.post(`${ADMIN}/accessories`, accessories.create);

    // Retrieve all accessories
    app.get(`${ADMIN}/accessories`, accessories.findAll);

    // Retrieve showcase accessories
    app.get(`${ADMIN}/accessories/type/:type`, accessories.findByType);

    // Retrieve a single Note with noteId
    app.get(`${ADMIN}/accessories/:_id`, accessories.findOne);

    // Update a Note with noteId
    app.put(`${ADMIN}/accessories/:_id`, accessories.update);

    // Delete a Note with noteId
    app.delete(`${ADMIN}/accessories/:_id`, accessories.delete);

    app.get(`${ADMIN}/users/`, users.findAll);

    app.patch(`${ADMIN}/users/:_id`, users.update);


    app.get(`${ADMIN}/dashboard/`, admin.getDash);


}