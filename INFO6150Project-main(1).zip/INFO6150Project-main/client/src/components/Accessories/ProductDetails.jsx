    import React from 'react'
    import {useState, useEffect} from 'react';
    import {useDispatch,useSelector} from 'react-redux';
    import { Route, NavLink, Redirect, useParams } from 'react-router-dom';

    import { getProductDetails } from '../../redux/actions/productActions';
    import { addToCart } from '../../redux/actions/cartActions';
    import Grid from '@material-ui/core/Grid';
    import Paper from '@material-ui/core/Paper';
    import Chip from '@material-ui/core/Chip';
    import Rating from '@material-ui/lab/Rating';
    import { withStyles } from '@material-ui/core/styles';
    import FavoriteIcon from '@material-ui/icons/Favorite';
    import Typography from '@material-ui/core/Typography';
    import Button from '@material-ui/core/Button';
    import ShoppingCartOutlinedIcon from '@material-ui/icons/ShoppingCartOutlined';
    import { addToCart as addToCartAction} from '../../redux/actions/cartActions';
    import ReactImageMagnify from 'react-image-magnify';
    import {withSnackbar} from '../../utils/snackbar';
    import './Products.css';


    const ProductDetails = (props) => {

        const StyledRating = withStyles({
            iconFilled: {
              color: '#ff6d75',
            }
          })(Rating);


          const dispatch = useDispatch();

          const productDetails = useSelector(state => state.getProductDetails);
          const {loading, error, product} = productDetails;
  
          const cartDetails = useSelector(state => state.cart);
          const {cartItems} = cartDetails;
 
          let [qty,setQty] = useState(0);

          useEffect(()=>{
            let item = cartItems.find(el => el.product === product._id);
            if(item)setQty(item.qty);
            else setQty(0);
          },[cartItems,product]);
      
        
        const addToCart = () => {
            setCartQuantity();
            
            setQty(++qty);
            dispatch(addToCartAction(product._id,qty));
            props.snackbarShowMessage(`Item added`);
        }

        const setCartQuantity = () => {
            cartItems.forEach(el => {
                if(el.product === product._id) setQty(el.qty);
            });
        }

        return (
            <div>
                <Grid container spacing={1} >
                    <Grid item xs={4} >
                        <Paper >
                            <div className="details-img" style={{paddingBottom:200, paddingLeft:200, paddingTop:100} }>
                                <ReactImageMagnify {...{
                                    smallImage: {
                                        alt: product?.title,
                                        src: product?.image != null ? product?.image : "/images/placeholder-image.png",
                                        width:350,
                                        height:350,
                                        marginBotton: 50
                                       
                                    },
                                    largeImage: {
                                        src: product?.image != null ? product?.image : "/images/placeholder-image.png",
                                        isFluidWidth: true,
                                        width: 1200,
                                        height: 1800,
                                    },
                                }}  enlargedImageContainerClassName="laregImageStyle"/>
                            </div>
                    </Paper>
                </Grid>
                <Grid item xs={7} style={{paddingTop:80, paddingLeft:100}}>
                    <div>
                        <h1>{product?.title}</h1>
                        <p className="p-desc">{product?.description}</p>
                        <StyledRating
                        name="customized-color"
                        defaultValue={product?.rating}
                        readOnly
                        size="medium"
                        precision={1}
                        icon={<FavoriteIcon fontSize="inherit" />}/>
                        <Chip
                            label={product?.type}
                            color="primary"
                        />
                        <div className="p-price">
                            <Typography variant="h6" component="span" className="s-span">
                                ${product?.price - (product?.price * product?.discount /100) || 0}
                            </Typography>
                            <Typography variant="body2" component="span" className="o-span">
                                {console.log(product?.price)}
                            ${product?.price}
                            </Typography>
                            <Typography variant="body2" component="span" className="discount-span">
                                {product?.discount > 0 ? product?.discount + "% Off":''}
                            </Typography>
                        </div>
                   
                        <Button size="large" variant="contained"
                        color="secondary"
                        onClick={addToCart}
                        startIcon={<ShoppingCartOutlinedIcon />}>
                            Add</Button>
                    </div>
                </Grid>
       
            </Grid>
        </div>
    )
}


export default withSnackbar(ProductDetails);