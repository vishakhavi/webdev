import { useTheme } from "@material-ui/core/styles";
import { ThemeProvider } from '@material-ui/styles';
import useMediaQuery from "@material-ui/core/useMediaQuery";
import { Typography, makeStyles } from '@material-ui/core';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardMedia from '@material-ui/core/CardMedia';
import { flexbox } from '@material-ui/system';
//import "./diet_appointment.css";

import { Height } from "@material-ui/icons";

import React, { Component } from "react";
import ReactDOM from "react-dom";
import AppointmentPicker from "react-appointment-picker";

import "./diet_appointment.css";

const useStyles = makeStyles(theme => ({
  root: {
    maxWidth: 300,
    [theme.breakpoints.down("sm")] : {
    maxWidth: 400,
    Height: 200
    }
  },
  media: {
    height: 140
  }
}));
export default class Aerobics_Appointment extends Component {
  state = {
    loading: false
  };

  addAppointmentCallback = ({ day, number, time, id }, addCb) => {
    this.setState(
      {
        loading: true
      },
      async () => {
        await new Promise(resolve => setTimeout(resolve, 500));
        console.log(
          `Added appointment ${number}, day ${day}, time ${time}, id ${id}`
        );
        addCb(day, number, time, id);
        this.setState({ loading: false });
      }
    );
  };

  removeAppointmentCallback = ({ day, number, time, id }, removeCb) => {
    this.setState(
      {
        loading: true
      },
      async () => {
        await new Promise(resolve => setTimeout(resolve, 500));
        console.log(
          `Removed appointment ${number}, day ${day}, time ${time}, id ${id}`
        );
        removeCb(day, number);
        this.setState({ loading: false });
      }
    );
  };

  render() {
    const days = [
      [
        { id: 1, number: 1, isReserved: true  },
        { id: 2, number: 2 },
        null,
        { id: 3, number: "3"},
        { id: 4, number: "4" },
        null,
        { id: 5, number: 5 },
        { id: 6, number: 6, isReserved: true  }
      ],
      [
        { id: 7, number: 7, isReserved: true },
        { id: 8, number: 8},
        null,
        { id: 9, number: "9"},
        { id: 10, number: "10", isReserved: true  },
        null,
        { id: 11, number: 11 },
        { id: 12, number: 12 }
      ],
      [
        { id: 13, number: 13 },
        { id: 14, number: 14 },
        null,
        { id: 15, number: 15, isReserved: true },
        { id: 16, number: "16" },
        null,
        { id: 17, number: 17},
        { id: 18, number: 18 }
      ],
      [
        { id: 19, number: 19 , isReserved: true },
        { id: 20, number: 20 },
        null,
        { id: 21, number: 21 },
        { id: 22, number: "22" },
        null,
        { id: 23, number: 23 },
        { id: 24, number: 24 }
      ],
      [
        { id: 25, number: 25, isReserved: true },
        { id: 26, number: 26 },
        null,
        { id: 27, number: "27", isReserved: true },
        { id: 28, number: "28" },
        null,
        { id: 29, number: 29 },
        { id: 30, number: 30, isReserved: true }
      ]
    ];
    const { loading } = this.state;
    return (
      <div class="center">
        <h1>Pick your slot for our Aerobics Virtual Sessions</h1>
        <h3>Limit: 3</h3>
        <AppointmentPicker
          addAppointmentCallback={this.addAppointmentCallback}
          removeAppointmentCallback={this.removeAppointmentCallback}
          initialDay={new Date("2021-04-24")}
          days={days}
          maxReservableAppointments={3}
          alpha
          visible
          selectedByDefault
          loading={loading}
        />
      </div>
    );
  }
}

//export default Diet_Appointment;
