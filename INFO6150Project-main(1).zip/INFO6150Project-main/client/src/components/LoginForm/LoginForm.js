import React, {useState} from 'react';
import axios from 'axios';
import './LoginForm.css';
import {API_BASE_URL, ACCESS_TOKEN_NAME,USER_DATA} from '../../constants/apiContants';
import { withRouter } from "react-router-dom";

function LoginForm(props) {
    const [state , setState] = useState({
        email : "",
        password : "",
        successMessage: null
    })
    const handleChange = (e) => {
        const {id , value} = e.target   
        setState(prevState => ({
            ...prevState,
            [id] : value
        }))
    }

    const handleSubmitClick = (e) => {
        e.preventDefault();
        const payload={
            "email":state.email,
            "password":state.password,
        }
        axios.post(API_BASE_URL+'/user/login', payload)
            .then(function (response) {
                if(response.status === 200 && response.data.token != null && response.data.message === "ADMIN"){
                    setState(prevState => ({
                        ...prevState,
                        'successMessage' : 'Login successful. Redirecting to home page..'
                    }))
                    localStorage.setItem(ACCESS_TOKEN_NAME,response.data.token);
                    localStorage.setItem(USER_DATA,JSON.stringify(response.data.data));
                    redirectToAdmin();
                    props.showError(null);
                }else if(response.status === 200 && response.data.token != null){
                    setState(prevState => ({
                        ...prevState,
                        'successMessage' : 'Login successful. Redirecting to home page..'
                    }))
                    localStorage.setItem(ACCESS_TOKEN_NAME,response.data.token);
                    localStorage.setItem(USER_DATA,JSON.stringify(response.data.data));
                    redirectToHome();
                    props.showError(null);
                }else if(response.status === 200 && response.data.message === "Incorrect Password!"){
                    console.log("Username and password do not match");
                    alert("Username and password do not match");
                    props.showError("Username and password do not match");
                }
                else if(response.status === 200 && response.data.message === "User Not Exist"){
                    console.log("Username does not exists");
                    alert("Username does not exists");
                    props.showError("Username does not exists");
                }
                else if(response.status === 200 && response.data.message === "User is Inactive"){
                    alert("User is Inactive");
                }     
                else{
                    alert("Server error");
                }
            })
            .catch(function (error) {
                console.log(error)
            });
    }
    const redirectToHome = () => {
        props.updateTitle('Home')
        props.history.push('/');
    }
    const redirectToAdmin = () => {
        props.updateTitle('Admin')
        props.history.push('/admin/home');
    }
    const redirectToRegister = () => {
        props.history.push('/register'); 
        props.updateTitle('Register');
    }
    return(
        <div>
             <p className="head" align="center">Welcome to LiveFit!</p>
             <div className="main">
            <p className="sign" align="center">Sign in</p>
            <form>
            <center>
                <div>
                <label htmlFor="exampleInputEmail1">Email address</label>
                <br></br>
                <input type="email" 
                       className="un "
                       id="email" 
                       aria-describedby="emailHelp" 
                       placeholder="Enter email" 
                       value={state.email}
                       onChange={handleChange}
                />
                </div>
                <div>
                <label htmlFor="exampleInputPassword1">Password</label>
                <br></br>
                <input type="password" 
                       className="pass"
                       id="password" 
                       placeholder="Password"
                       value={state.password}
                       onChange={handleChange} 
                />
                </div>
                <div>
                </div>
                <button 
                    type="submit" 
                    className="button"
                    onClick={handleSubmitClick}
                >Submit</button>
                </center>
            </form>
            <div style={{display: state.successMessage ? 'block' : 'none' }} role="alert">
                {state.successMessage}
            </div>
            <div className="registerMessage">
                <center>
                <span>Dont have an account? </span>
                    <span className="loginText" onClick={() => redirectToRegister()}>Register</span> 
                </center>
            </div>
            </div>
        </div>
    )
}

export default withRouter(LoginForm);