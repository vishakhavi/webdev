import AccessoriesList from './Accessories/AccessoriesList';
import AccessoriesShowCase from './Accessories/AccessoriesShowCase';
import Terms from './TermsAndConditionsForm/Terms';
import Privacy from './PrivacyForm/Privacy';
import Contact from './ContactUsForm/Contact';

const routes = [{
        path: `/accessories`,
        text: "home",
        main: () => < AccessoriesShowCase / >
    }, {
        path: `/product/type/:type`,
        text: "product",
        main: () => < AccessoriesList / >
    }, {
        path: `/terms`,
        text: "terms",
        main: () => < Terms / >
    }, {
        path: `/privacy`,
        text: "privacy",
        main: () => < Privacy / >
    }, {
        path: `/contact`,
        text: "contact",
        main: () => < Contact / >
    }




];

export default routes;