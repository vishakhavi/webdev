# INFO6150Project

To run this project

Navigate to client folder
Hit npm install
Go back


Navigate to server folder
Hit npm install
Go back


In root folder
Hit npm install


To Run:-

React Server - npm run client

Node Server - npm run server

Both Server - npm run start




Happy Coding :)
