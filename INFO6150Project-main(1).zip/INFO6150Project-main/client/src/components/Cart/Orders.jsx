import React, { useState } from 'react'
import IconButton from '@material-ui/core/IconButton';
import AddIcon from '@material-ui/icons/Add';
import RemoveIcon from '@material-ui/icons/Remove';
import './Cart.css';
import HighlightOffIcon from '@material-ui/icons/HighlightOff';

const Orders = (props) => {
    console.log(props);
    console.log("props");


    return (
        <div className="item-wrapper">
            <div className="image">
                <img src={props?.image} alt="products"/>
            </div>
            <div className="desc">
                <div className="left-float">
                    <span className="title">{props?.title}</span>
                    <span className="price">${props?.price - (props?.price * props?.discount /100) || 0}</span>
                </div>
                {props.qty}
            </div>
        </div>
    )
}

export default Orders;
