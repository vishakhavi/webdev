import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import Typography from '@material-ui/core/Typography';
import sunrise from "../images/exercise.jpg"

const useStyles = makeStyles((theme) => ({
  root: {
   // flexGrow: 1,
   paddingLeft: 60
  },
  paper: {
    padding: 20,
    margin: 10,
    maxWidth: 1500,
    borderRadius: 20
  },
  image: {
    width: 800,
    borderRadius: 20

  },
  img: {
    margin: 10,
    display: 'block',
    maxWidth: '100%',
    maxHeight: '100%',
    borderRadius: 20
    
  },
}));

export default function GridCard() {
  const classes = useStyles();

  return (
    <div className={classes.root}>
      <Paper className={classes.paper}>


        <Grid container >

        <Grid item xs container direction="row" spacing={1}>
              <Grid item xs>
                <Typography gutterBottom variant="h3" >
               
                Exercise is therapy.  
                </Typography>
               
              
          
                <Typography variant="h6" gutterBottom>
                Exercise enhances or maintains the overall wellness of the body. It supports physical fitness and health. People perform the home exercise to improve strength, develop muscles, lose weight, aid growth, and prevent ageing. One should always keep in mind that spending some time on daily fitness is better than not doing anything.
                </Typography>
               
              </Grid>
             
            </Grid>
          
          <Grid item xs container spacing={1}>
            <Grid item xs container direction="row" spacing={7} >
              <Grid item xs className={classes.image}>
              <img className={classes.img} alt="complex" src={sunrise} />
              </Grid>
             
            </Grid>
   
           
            
          </Grid>
        </Grid>
      </Paper>
    </div>
  );
}
