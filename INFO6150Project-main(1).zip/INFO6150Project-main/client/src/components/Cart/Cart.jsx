import React, { useState } from 'react'
import Badge from '@material-ui/core/Badge';
import IconButton from '@material-ui/core/IconButton';
import ShoppingCartIcon from '@material-ui/icons/ShoppingCart';
import CancelIcon from '@material-ui/icons/Cancel';
import { makeStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import Divider from '@material-ui/core/Divider';
import CartItems from './CartItems';
import './Cart.css';
import {useEffect} from 'react';
import {useDispatch,useSelector} from 'react-redux';
import {Link,BrowserRouter as Router,Switch, Route} from 'react-router-dom';
import {addToCart ,clearCart,removeFromCart} from '../../redux/actions/cartActions';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
// import Snackbar from '@material-ui/core/Snackbar';
import PaypalExpressBtn from 'react-paypal-express-checkout';
import CheckIcon from '@material-ui/icons/Check';
import PageNotFound from '../NotFound/PageNotFound';
import OrdersHistory from '../OrdersHistory/OrdersHistory';
import axios from 'axios';
import { PromiseProvider } from 'mongoose';
const useStyles = makeStyles({
  drawer: {
        width: 20,
    },
    fullList: {
        // width: 'auto',
    },
});




export default function Cart() {
    const classes = useStyles();
    const dispatch = useDispatch();
    const [open, setOpen] = useState(false);
    const [user,setUser] = useState(null);

    useEffect(()=>{
        if(localStorage.getItem("user_data") != undefined){
          let userdata = JSON.parse(localStorage.getItem("user_data"));
          setUser(userdata._id);
        }
    })
  
    const handleDrawerOpen = () => {
      setOpen(true);
    };
  
    const handleDrawerClose = () => {
      setOpen(false);
    };

    const cart = useSelector(state => state.cart);

    const { cartItems } = cart;

    const changeQty = (id,val) => {
      let item = cartItems.find(el=> el.product === id);
      let qty = item.qty
      if(val)++qty;
      else --qty;
      dispatch(addToCart(id,qty));
    }

    const removeCart = (id) => {
      dispatch(removeFromCart(id));
    }

    const getCartCount = () => {
      return cartItems.reduce((qty,item)=> Number(item.qty) + qty,0);
    }

    const getSubTotal = () => {
      return cartItems.reduce((price,item)=> item.qty * (item?.price - (item?.price * item?.discount /100)) + price,0);
    }

    const client = {
      sandbox:    'AQ6cLZcNwwQm3QVNd1ly4L9aauShS4F9tpx__6UaBK3BIsgGX4_7aJ0Vp3UEYds4y71nUVN2_VZLkKT_',
      production: 'EHa_ogXyygr_qm5gZr6692XYLGfspk8t8FIO2ZgoOX3AnuXoc805zxuqD9LYg14BLRN6OsgqcB8HbyAY',
    }

    

    const saveOrder = async() => {
     
      console.log(cartItems);
      let obj = {products:cartItems,userId:user};
      await axios.post(`/user/orders`,obj);
      dispatch(clearCart());
      
      window.location.href = '/history'; 

      console.clear();
    }

    const onCancel = () => {
      saveOrder();
    }



    const list = () => (
      <div className="cart-list">
        <h2 className="cart-header">Cart</h2>
        {cartItems?.length === 0 ? (<div className="empty-cart">
          <img  src="/images/empty-cart.png" alt="Empty Cart"/>
        </div>) : (
          cartItems.map((el) => (
            <List key={el.product}><ListItem><CartItems  {...el}  changeQty={changeQty} removeItem={removeCart}/> </ListItem><Divider/></List>
          ))
        )}
        {cartItems.length > 0 ? <div className="cart-price-desc">
            <p>Subtotal ({getCartCount()} items) <span>${getSubTotal().toFixed(2)}</span> </p>
            <PaypalExpressBtn client={client} currency={'USD'} total={getSubTotal().toFixed(2)} onError={onCancel} onCancel={onCancel}/>

            {/* <Router>
              <Link to="/history">
                <IconButton onClick={emptyCart}>
                  <CheckIcon />
                </IconButton>
              </Link>
            </Router> */}
        </div>:''}
      </div>
    );

    return (
        <div>
            <IconButton onClick={handleDrawerOpen} className="cart-btn" fontSize="large" style={{  color: 'white'}}>
                {cartItems.length === 0 ? (<ShoppingCartIcon />) : 
                (
                  <Badge badgeContent={getCartCount()} color="primary">
                    <ShoppingCartIcon color="secondary" fontSize="large" style={{color:'white'}} />
                  </Badge>
                )}
            </IconButton>
                  
            <Drawer
              className={classes.drawer}
              variant="persistent"
              anchor="right"
              open={open}
              classes={{
                paper: classes.drawerPaper,
              }}
            >
                <IconButton onClick={handleDrawerClose}>
                  <CancelIcon />
                </IconButton>
              {list()}

            </Drawer>
        </div>
    )
}
