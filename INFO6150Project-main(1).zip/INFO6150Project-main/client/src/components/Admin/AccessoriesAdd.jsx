import React, { Component } from 'react'
import { TYPE ,STATUS,} from '../../utils/constants';
import { TextField , MenuItem, TextareaAutosize , FormLabel, Button} from '@material-ui/core';
import ImageCrop from './ImageCrop';
import {
    BrowserRouter as Router,
    Switch,
    Route,
    Link
  } from "react-router-dom";



const axios = require('axios');
const {DOMAIN_URL, ACCESSORIES} = require('../../utils/constants');


export default class AccessoriesAdd extends Component {
    constructor(props){
        super(props);
        this.validateForm = this.validateForm.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.onCropFile = this.onCropFile.bind(this);
        this.state={
            title:null,
            type:null,
            description:null,
            rating:null,
            image:null,
            price:null,
            errors:{
                title:'',
                type:'',
                description:'',
                rating:'',
                image:'',
                price:''
            }
        }
    }

    handleChange(event){
        event.preventDefault();
        console.log(event.target);
        const { name, value } = event.target;
        let errors = this.state.errors;

        // switch (name) {
        //     case 'title': 
        //       errors.title = 
        //         value.length < 2
        //           ? 'Title must be 2 characters long!'
        //           : '';
        //       break;
        //     case 'description': 
        //       errors.description = 
        //         value.length < 5
        //         ? 'Description must be 5 characters long!'
        //         : '';
        //       break;
        //     case 'price': 
        //       errors.price = 
        //         value.length < 1
        //           ? 'Password must be 8 characters long!'
        //           : '';
        //       break;
        //     case 'discount': 
        //       errors.discount = 
        //         value.length < 1
        //           ? 'Password must be 8 characters long!'
        //           : '';
        //       break;
        //       case 'type': 
        //       errors.type = 
        //         value.length < 1
        //           ? 'Password must be 8 characters long!'
        //           : '';
        //       break;
        //     default:
        //       break;
        //   }
      
          this.setState({errors, [name]: value});
    }

    validateForm(errors){
        console.log("errors ",errors);
        let valid = true;
        Object.values(errors).forEach(
          (val) => val.length > 0 && (valid = false)
        );
        return valid;
    }

    handleSubmit(event){
        event.preventDefault();
        if(this.validateForm(this.state.errors)) {
          console.info('Valid Form');
          console.log(this.state);
          let obj = this.state;
          delete obj.errors;

            const formData = new FormData();
            // let data = JSON.parse(JSON.stringify(obj));
            // delete data['image'];
            // formData.append('title', "ABV");
            // formData.append('type', "RUN");
            // formData.append('description', "obj.description");
            // formData.append('price', 300);
            // formData.append('discount', 10);
            // formData.append('status', "ACTIVE");

            formData.append('title', obj.title);
            formData.append('type', obj.type);
            formData.append('description', obj.description);
            formData.append('price', obj.price);
            formData.append('discount', obj.discount);
            formData.append('status', obj.status);

            formData.append('image', obj.image);

            this.submitData(formData);
        }else{
          console.error('Invalid Form')
        }
    }

    onCropFile(blobFile){
        console.log(blobFile);
        this.setState({...this.state,image:blobFile})
    }

    submitData(obj){
        axios.post(`${DOMAIN_URL}/admin/${ACCESSORIES}`,obj)
        .then(function (response) {
            // handle success
            console.log(response);
        })
        .catch(function (error) {
            // handle error
            console.log(error);
        })
    }


    render() {
        return (
            <div className="form-wrapper">
                <h2>Add Product</h2>
                <div>
                    <form noValidate autoComplete="off" onSubmit={this.handleSubmit}>
                        <div className="image-upload">
                            <ImageCrop cropFile={this.onCropFile}/>
                        </div>
                        <div className="field">
                            <FormLabel>Title</FormLabel>
                            <TextField onChange={this.handleChange} name="title" />
                        </div>
                        <div className="field">
                            <FormLabel>Description</FormLabel>
                            <TextareaAutosize  name="description" rows="3" cols="28" onChange={this.handleChange}  />
                        </div>
                        <div className="field">
                            <FormLabel>Select</FormLabel>
                            <TextField
                                id="standard-select"
                                select
                                onChange={this.handleChange}
                                name="type"
                                >
                                {Object.values(TYPE).map((option) => (
                                    <MenuItem key={option} value={option}>
                                    {option}
                                    </MenuItem>
                                ))}
                            </TextField>
                        </div>
                        <div className="field">
                            <FormLabel>Price</FormLabel>
                            <TextField onChange={this.handleChange} name="price" />
                        </div>
                        <div className="field">
                            <FormLabel>Discount</FormLabel>
                            <TextField onChange={this.handleChange} name="discount" />
                        </div>
                        <div className="field">
                            <FormLabel>Status</FormLabel>
                            <TextField
                                id="standard-select"
                                select
                                onChange={this.handleChange}
                                name="status"
                                >
                                {Object.values(STATUS).map((option) => (
                                    <MenuItem key={option} value={option}>
                                    {option}
                                    </MenuItem>
                                ))}
                            </TextField>
                        </div>

                        <div>
                        <Button variant="contained" color="primary" type="submit">
                            Submit
                        </Button>
                        <Link to="/admin/product">
                            <Button variant="contained" color="primary" type="submit">
                                Back
                            </Button>
                        </Link>
                        </div>
                    </form>
                </div>
            </div>
        )
    }
}
