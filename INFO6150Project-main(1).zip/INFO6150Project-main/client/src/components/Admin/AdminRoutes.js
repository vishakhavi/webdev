import AdminWelcome from './AdminWelcome';
import AccessoryList from './AccessoryList';
import UserList from './UsersList';

const ADMIN = `/admin`
const routes = [{
        path: `${ADMIN}/home`,
        text: "home",
        main: () => < AdminWelcome / >
    }, {
        path: `${ADMIN}/product`,
        text: "product",
        main: () => < AccessoryList / >
    },
    {
        path: `${ADMIN}/users`,
        text: "Users",
        exact: true,
        main: () => < UserList / >
    },



];

export default routes;