import React, { Component } from 'react';
import Carousel from '@brainhubeu/react-carousel';
import '@brainhubeu/react-carousel/lib/style.css';
import  { autoplayPlugin } from '@brainhubeu/react-carousel';
import Icon from 'react-fa';
import image1 from "../images/rope.jpg"
import image2 from "../images/caro1.jpg"
import image3 from "../images/trainer.jpg"
import { slidesToShowPlugin } from '@brainhubeu/react-carousel';

export default class MyCarousel extends Component {
  render() {
    return (
        <Carousel style={{ }}
        
        
        
        centered
        plugins={['arrows']}
        
        slidesPerPage= {1}
        slidesPerScroll={1}
        
        plugins={[
          'infinite',
         {
           resolve: autoplayPlugin,
           
           options: {
             interval: 2000,
           }
         },
       ]}   
       animationSpeed={800}
      
      >
        <img src={image1} width='84%' height='600px'  />
        <img src={image2} width='84%' height='600px'   />
        <img src={image3} width='84%' height='600px'  />
      </Carousel>
    );
  }
}