require('dotenv').config();
const mongoose = require('mongoose');

const connectDB = async() => {
    try {
        mongoose.Promise = global.Promise;
        await mongoose.connect(process.env.MONGO_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            useFindAndModify: false,
            useCreateIndex: true
        });

        console.log("MongoDB connected successfully !!");
    } catch (err) {

        console.log("Error in MongoDB connectivity");
        process.exit(1);
    }
}

module.exports = connectDB;