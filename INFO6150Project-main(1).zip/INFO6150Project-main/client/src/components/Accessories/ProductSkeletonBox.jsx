import React from 'react'
import Skeleton from '@material-ui/lab/Skeleton';
import Box from '@material-ui/core/Box';

const ProductSkeletonBox = () => {
    return (
        <Box pt={0.5}>
            <Skeleton variant="rect" width={260} height={220} />
            <Skeleton variant="text" width={260}/>
            <Skeleton variant="text" width={260}/>
            <Skeleton variant="text" width={260}/>
            <Skeleton variant="text" width={260}/>
            <Skeleton  width={180}/>
            <Skeleton  width={180}/>
        </Box>
    )
}

export default  ProductSkeletonBox;
