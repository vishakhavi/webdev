import { useTheme } from "@material-ui/core/styles";
import { ThemeProvider } from '@material-ui/styles';
import useMediaQuery from "@material-ui/core/useMediaQuery";
import { Typography, makeStyles } from '@material-ui/core';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardMedia from '@material-ui/core/CardMedia';
import { flexbox } from '@material-ui/system';
import "./cards.css";
import diet from "../images/diet.jpeg"
import jump from "../images/jump.jpeg"
import help from "../images/help.jpg"
import dumpbell from "../images/dumbell.jpg"
import { Height } from "@material-ui/icons";


const useStyles = makeStyles(theme => ({
  root: {
    
    [theme.breakpoints.down("sm")] : {
    maxWidth: 400,
    Height: 200
    }
  },
  media: {
    height: 140
  }
}));
const Cards = (props) =>  {
  const classes = useStyles();
  const theme = useTheme();

 // const matches = useMediaQuery(theme.breakpoints.up("sm"));
  return (

    <Card className={classes.root}>
      <CardActionArea>
        <CardMedia
          className={classes.media}
          image={props.picture}
          title="Contemplative Reptile"
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="h2">
            {props.data_header}
          </Typography>
          <Typography variant="body2" color="textSecondary" component="p">
            {props.details}
          </Typography>
        </CardContent>
      </CardActionArea>
    
    </Card>
  );
}

const ShowCard = () => 
{
  var divStyle = {
    fontFamily: "sans-serif",
    fontWeight: "bold",
    padding: 30,
    margin: 3,
    display: 'flex',
    flexDirection: 'row',
    flex: '4'
};

  const matches = useMediaQuery('(min-width:400px)');
  const matches2 = useMediaQuery('(max-width:600px)');
  if(matches)
  {
  return(
    <div style={divStyle}>
      <Cards class="cardStyle" picture={diet} data_header="Dance Activity" details="Fun workout to dance your will boost your health and relieve stress."></Cards>
      <div style={{margin: 10, padding:5}}></div>
      <Cards class="cardStyle" picture={jump} data_header="Need Assitant?" details="We have certified trainers can guide with proper and efficient techniques."></Cards>
      <div style={{margin: 10, padding:5}}></div>
      <Cards class="cardStyle" picture={help} data_header="Diet" details="Designed by outr nutritionist, an easy to follow healthy diet and stay fit"></Cards>
      <div style={{margin: 10, padding:5}}></div>
      <Cards class="cardStyle" picture={dumpbell} data_header="Body Building" details="To keep you fit healthy through a range of holistic offerings include fitness"></Cards>
      </div>
  )
  } else {
    return(
      <div style={{padding: 10}}>
         <Cards class="cardStyle1" picture={diet} data_header="Dance Activity" details="Fun workout to dance your way into fitness that will boost your health and relieve stress."></Cards>
         <div style={{margin: 10, padding:3}}></div>
         <Cards class="cardStyle1" picture={jump} data_header="Need Assitant?" details="We have certified trainers who can guide with proper and efficient techniques."></Cards>
         <div style={{margin: 10, padding:3}}></div>
         <Cards class="cardStyle1" picture={help} data_header="Diet" details="Designed by out nutritionist, an easy to follow healthy diet"></Cards>
         <div style={{margin: 10, padding:3}}></div>
         <Cards class="cardStyle1" picture={dumpbell} data_header="Body Building" details="To keep you fit & healthy through a range of holistic offerings that include"></Cards>
         <div style={{margin: 10, padding:3}}></div>
        </div>
    )
  }

}
export default ShowCard;