import React, { Component } from 'react';


export default class Privacy extends Component {

  render() {
    return(
      <div>
          <h1>PRIVACY POLICY</h1>
           <p>  We at Diverse Retails Private Limited ('LiveFit', 'We', 'Us',
                    'Our')
                    know that you as a user ('You', 'Your', ‘User(s)’) care about how your
                    personal information
                    is used and shared, and we take your privacy seriously. Please read the following to learn more
                    about our privacy
                    policy. By visiting or using our website (www.live.fit) and domain name, and any other linked
                    pages, features,
                    content, mobile applications, or any other services we offer from time to time by in connection
                    therewith (collectively,
                    the 'Mobile App'), or by using the Services / Products (as defined in our
                 Terms of Use) in any manner, you acknowledge that you accept the practices and policies outlined
                    in this privacy
                    policy, and you hereby consent that we will collect, use, and share your information in the
                    following ways.
            
            </p>
            <p class="c13"></p>
            <p class="c36"><span class="c25 c35">If you reside in or use / access the Mobile App in United Arab
                    Emirates, Privacy Policy for UAE region,
                    as published immediately below this privacy policy, shall apply. </span></p>
            <p name="1"><span class="c0"></span></p>
            <span class="c4 heading">What does this privacy policy cover? </span>
            <p class="c13 c22"></p>
            <p class="c2"><span class="c0">This privacy policy covers our treatment of personally identifiable
                    information ('personal information')
                    that we gather when you are accessing or using our Mobile App and Products. This policy does
                    not apply to the
                    practices of companies that we do not own or control, or to individuals that we do not employ
                    or manage.</span></p>
             
            <p ></p>
           
            <p>
                <span>We do not knowingly collect or solicit personal information from anyone
                    under the&nbsp;age of 18
                    or knowingly allow such persons to register for the Products. If you are&nbsp;under 18, please
                    do not attempt
                    to register for the Products or send any information about yourself to us, including your name,
                    address, telephone
                    number, email address or provide your biometric information.&nbsp;No one under age 18&nbsp;may
                    provide any personal
                    information to us or on the Products. In the event that we learn that we have collected
                    personal information
                    from a child&nbsp;under age 18&nbsp;without verification of parental consent, we will delete
                    that information
                    as quickly as possible.
                    <p ></p>
                    If you believe that we might have any information from or&nbsp;about a
                    child under 18,
                    please contact us at&nbsp;
                    <span >
                        <a href="mailto:hello@live.fit">hello@live.fit</a>
                    </span>.</span>
            </p>
          </div>
          )}
    }
