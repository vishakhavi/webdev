
import AppBar from '@material-ui/core/AppBar';
import Typography from '@material-ui/core/Typography';
import Container from '@material-ui/core/Container';
import Toolbar from '@material-ui/core/Toolbar'

import FacebookIcon from '@material-ui/icons/Facebook';
import InstagramIcon from '@material-ui/icons/Instagram';
import TwitterIcon from '@material-ui/icons/Twitter';
import WhatsAppIcon from '@material-ui/icons/WhatsApp';
import GitHubIcon from '@material-ui/icons/GitHub';
import FormHelperText from '@material-ui/core/FormHelperText';
import TextField from '@material-ui/core/TextField';
import  emailjs from 'emailjs-com'
import React, { Component } from 'react'
import {  Input } from 'reactstrap'
import Link from '@material-ui/core/Link';



import FilledInput from '@material-ui/core/FilledInput';

import InputLabel from '@material-ui/core/InputLabel';
import InputAdornment from '@material-ui/core/InputAdornment';

import FormControl from '@material-ui/core/FormControl';

import {IconButton,
    Drawer,
    Links,
    MenuItem,
  } from "@material-ui/core";
import clsx from "clsx";
// @material-ui/core components
import { makeStyles } from "@material-ui/core/styles";
import Box from "@material-ui/core/Box";
import Button from "@material-ui/core/Button";
import { VerticalAlignCenterSharp } from '@material-ui/icons';
import ReactTooltip from 'react-tooltip';
// @material-ui/icons components
// core components

//import componentStylesButtons from "assets/theme/components/button.js";

//const useStylesButtons = makeStyles(componentStylesButtons);
const useStyles = makeStyles((theme) => ({
  root: {
     display: 'flex',
     flexWrap: 'wrap',
     alignContent: 'center',
     justifyContent: 'center',
     marginBottom:'10px'
     //backgroundColor: 'black'
  },
  margin: {
    margin: theme.spacing(1),
    color: 'white',
    alignContent: 'center',
  },
  withoutLabel: {
    marginTop: theme.spacing(3),
    alignContent: 'center',
  },
  textField: {
    width: '34ch',
   // height: '20',
    backgroundColor: 'White',
   alignContent: 'center',
    marginBottom: 19,
    marginLeft: 40
  },
  appBarBackground:
  {
    color: 'white',
     background : '#343434', 
  justifyContent: 'center'  
},
appBarBackground2:
{
  color: 'white',
   background : 'black',
   justifyContent: 'center'

  },
  typo:
  {
    color: 'white',
    marginLeft: 20,
    marginBottom: 4,
    marginTop: 50,
    //VerticalAlignCenterSharp: 'center'
  },
  link: {
    color: 'white'
  },
  button:  {
   // size: 'small',
    color: 'white',
    backgroundColor: '#343434',
    marginLeft: 20,
    margin: theme.spacing(1),
    marginBottom: 18
  },
  heading: {
    marginLeft: 100,
    color: 'white'
  },
  typography: {
    color: 'white'
  },
  divstyle:
  {
    marginLeft: 50,
    maxWidth: 500,
    color: 'white'
  },
  footer_div:
  {
    display: 'flex',
    flexWrap: 'wrap',
    marginBottom: 30,
    margin: theme.spacing(1),

  //   alignContent: 'center',
    justifyContent: 'center',
    color:'white'
  },
  contact_date:
  {
    color:'white',
    maxWidth: 270, 
   // marginLeft: 100,
    justifyContent: 'center'
  },
  contact_header:
  {
    marginLeft: 100,
    color:'white'
  }
}));
 function Data(props)
 {
  const classes = useStyles();
   
    
  // const divStyle = {alignItems: 'center', flexGrow: 1};
  // const style2 = {wrapIcon: {
  //     alignItem: 'center',
  //     display: 'inline-flex',
      
  //    }};
     const [values, setValues] = React.useState({
      amount: '',
      password: '',
      weight: '',
      weightRange: '',
      showPassword: false,
    });

    
    const handleChange = (prop) => (event) => {
      setValues({ ...values, [prop]: event.target.value });
    };
   return(
     <div className={classes.root}>
 <Typography variant="subtitle1" gutterBottom  />
       Sign up for our newsletter
     
       <ContactForm></ContactForm>
 
        
      
     </div>
   )
 }

 function Aboutus()
 {
  const classes = useStyles();
   return(
     <div className={classes.divstyle} >
        <Typography variant="h6" gutterBottom className={classes.heading}>
        ABOUT US
      </Typography>
      <Typography variant="body1" gutterBottom className={classes.typography}>
      At LiveFit, we make group workouts fun, daily food healthy & tasty, mental fitness
      easy with yoga & meditation, and medical & lifestyle care hassle-free.
      </Typography>
      <tr>
      <td><a className={classes.link} href={"/terms"}>Terms&Conditions</a></td>     
      
  </tr>
     </div>
   )
 }
 function ContactUs()
 {
  const classes = useStyles();
   return(
     <div  >
        <Typography variant="h6" gutterBottom className={classes.contact_header}>
        CONTACT
      </Typography>
      
      <Typography variant="body1" gutterBottom className={classes.contact_date}>
          360 Huntington St, Boston 02215
    Phone: 333 593 2347
    Email: livefit@gmail.com
    Skype: livefitskype
      </Typography>
      <tr>
      <td><a className={classes.link} href={"/privacy"}>Privacy Policy</a></td>
  </tr>
     </div>
   )
 }
export default function Footer(props) {
  const classes = useStyles();
   
    
    // const divStyle = {alignItems: 'center', flexGrow: 1};
    // const style2 = {wrapIcon: {
    //     alignItem: 'center',
    //     display: 'inline-flex',
        
    //    }};
       const [values, setValues] = React.useState({
        amount: '',
        password: '',
        weight: '',
        weightRange: '',
        showPassword: false,
      });
      const preventDefault = (event) => event.preventDefault();
      const handleChange = (prop) => (event) => {
        setValues({ ...values, [prop]: event.target.value });
      };
    return (
        <div >
            <AppBar position="static"  className={classes.appBarBackground}>
          <Container maxWidth="md" className={classes.root}>
            
          
         <a href="https://www.facebook.com/" target='_blank'>  <IconButton style={{ color: 'white'}}   color="inherit" aria-label="AccessibilityNewIcon">
    <FacebookIcon fontSize="small" />
      </IconButton></a>
      
      <a href="https://twitter.com/?lang=en" target='_blank'> <IconButton style={{ color: 'white'}}   color="inherit" aria-label="AccessibilityNewIcon">
    <TwitterIcon fontSize="small" />
      </IconButton></a>
      <a href="https://www.instagram.com/" target='_blank'>  <IconButton style={{  color: 'white'}}  color="inherit" aria-label="AccessibilityNewIcon">
    <InstagramIcon fontSize="small" />
      </IconButton></a>
      <a href="https://github.com/" target='_blank'> <IconButton style={{ color: 'white'}} color="inherit" aria-label="AccessibilityNewIcon">
    <GitHubIcon fontSize="small" />
      </IconButton></a>
      <a href="https://web.whatsapp.com/" target='_blank'> <IconButton style={{  color: 'white'}}  color="inherit" aria-label="AccessibilityNewIcon">
    <WhatsAppIcon fontSize="small" />
      </IconButton></a>
                 
          </Container>
         <Data></Data>
        <Footer_Data></Footer_Data>
        {/* <ContactForm></ContactForm> */}
        </AppBar>
        
        <AppBar position="static" className={classes.appBarBackground2} >
          <Container maxWidth="md" className={classes.root}>
            <Toolbar>
              <Typography variant="body1" color="inherit">
                © 2021 Livefit
              </Typography>
            </Toolbar>
          </Container>
        </AppBar>
        </div>
    )
}

function Footer_Data()
{
  const classes = useStyles();
  return(
    <div className={classes.footer_div}>
    <Aboutus></Aboutus>
    <ContactUs></ContactUs>
    </div>

  )
}

class ContactForm extends Component {
  state = {
    name: '',
    email: '',
    subject: '',
    message: '',
  }
handleSubmit(e) {
    e.preventDefault()
    const { name, email, subject, message } = this.state
    let templateParams = {
      from_name: 'email',
      to_name: email,
      subject: subject,
      message_html: message,
     }
     emailjs.send(
      'service_bozir1g',
      'template_iery72d',
       templateParams,
      'user_1EM0JDjVUmCSp2tsPpRhA'
     )
     this.resetForm()
 }
resetForm() {
    this.setState({
      name: '',
      email: '',
      subject: '',
      message: '',
    })
  }
handleChange = (param, e) => {
    this.setState({ [param]: e.target.value })
  }

 
 
render() {
 // const classes = useStyles();
    return (
      <>
       
         
          <form  noValidate autoComplete="off" onSubmit={this.handleSubmit.bind(this)}>
          
          {/* <TextField
          id="outlined-margin"
          value={this.state.email}
          //type="email"
          name="email"
          onChange={this.handleChange.bind(this, 'email')}
         // label="Uncontrolled"
          //className={classes.textField}
          //defaultValue="foo"
          variant="standard"
        /> */}
        <Input
                type="email"
                name="email"
                style={{alignContent: 'center', backgroundColor: 'white',marginTop:-5,marginBottom: 30,marginLeft:10, width: 300, height:30}}
                value={this.state.email}
                className="text-primary"
                onChange={this.handleChange.bind(this, 'email')}
                //placeholder="Enter email"
              />
             
 <Button size="small" style={{backgroundColor:'white', marginLeft:10}} variant="outlined" type="submit" >Submit</Button>

          </form>
        
      </>
    )
  }
}
//export default ContactForm
// export default function Footer(){
//     return(
//                 <div>
            
//              <top_footer></top_footer>
//                 </div>
//     )
// }
