import React, {Components} from 'react';


export default class ContactUs {
    render(){
        return(
            <div>
               <p>CONTACT :</p>
               <br/>
      
      <p>
          360 Huntington St, Boston 02215
    Phone: 333 593 2347
    Email: livefit@gmail.com
    Skype: livefitskype
      </p> 
            </div>
        )
    }
}