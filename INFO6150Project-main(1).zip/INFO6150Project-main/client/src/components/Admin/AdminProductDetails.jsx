    import React from 'react'
    import {useState, useEffect} from 'react';
    import { Route, NavLink, Redirect, useParams ,useHistory} from 'react-router-dom';

    import { addToCart } from '../../redux/actions/cartActions';
    import Grid from '@material-ui/core/Grid';
    import Paper from '@material-ui/core/Paper';
    import Chip from '@material-ui/core/Chip';
    import Rating from '@material-ui/lab/Rating';
    import { withStyles } from '@material-ui/core/styles';
    import FavoriteIcon from '@material-ui/icons/Favorite';
    import Typography from '@material-ui/core/Typography';
    import Button from '@material-ui/core/Button';
    import ReactImageMagnify from 'react-image-magnify';
    import axios from 'axios';
    import {withSnackbar} from '../../utils/snackbar';
    import '../Accessories/Products.css';


    const AdminProductDetails = (props) => {

        const StyledRating = withStyles({
            iconFilled: {
              color: '#ff6d75',
            }
          })(Rating);
        const params = useParams();
        const history = useHistory();
        console.log(props);
        useEffect(()=>{
            getProductDetails();
        },[]);

        let [product,setProductDetails] = useState(null);

        const getProductDetails = async() => {
            let { data } = await axios.get(`/accessories/${params._id}`);
            data = data.data;
            setProductDetails(data);
        }

        const deleteProduct = async() => {
            let { data } = await axios.delete(`/admin/accessories/${params._id}`);
            console.log(data);
            if(data.statusCode == 200){
                setTimeout(() => history.goBack(), 1000);
                props.snackbarShowMessage(data.message);
            }
        }
      
        
        return (
            <div>
                <Grid container spacing={3}>
                    <Grid item xs={5}>
                        <Paper>
                            <div className="details-img">
                                <ReactImageMagnify {...{
                                    smallImage: {
                                        alt: product?.title,
                                        src: product?.image,
                                        width:350,
                                        height:350
                                    },
                                    largeImage: {
                                        src: product?.image,
                                        isFluidWidth: true,
                                        width: 1200,
                                        height: 1800,
                                    },
                                }}  enlargedImageContainerClassName="laregImageStyle"/>
                            </div>
                    </Paper>
                </Grid>
                <Grid item xs={7}>
                    <div>
                        <h1>{product?.title}</h1>
                        <p className="p-desc">{product?.description}</p>
                        <StyledRating
                        name="customized-color"
                        defaultValue={product?.rating}
                        readOnly
                        size="medium"
                        precision={1}
                        icon={<FavoriteIcon fontSize="inherit" />}/>
                        <Chip
                            label={product?.type}
                            color="primary"
                        />
                        <div className="p-price">
                            <Typography variant="h6" component="span" className="s-span">
                                ${product?.price - (product?.price * product?.discount /100) || 0}
                            </Typography>
                            <Typography variant="body2" component="span" className="o-span">
                            ${product?.price}
                            </Typography>
                            <Typography variant="body2" component="span" className="discount-span">
                                {product?.discount > 0 ? product?.discount + "% Off":''}
                            </Typography>
                        </div>
                        <Button size="large" variant="contained"
                        color="secondary"
                        onClick={deleteProduct}
                        >Delete</Button>
                    </div>
                </Grid>
       
            </Grid>
        </div>
    )
}


export default withSnackbar(AdminProductDetails);