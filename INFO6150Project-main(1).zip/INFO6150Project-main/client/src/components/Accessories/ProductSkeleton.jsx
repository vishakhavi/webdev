import React from 'react'
import ProductSkeletonBox from './ProductSkeletonBox';

export default function ProductSkeleton() {
    return (
        <div className="skeleton-wrapper">
           <ProductSkeletonBox/>
           <ProductSkeletonBox/>
           <ProductSkeletonBox/>
           <ProductSkeletonBox/>
           <ProductSkeletonBox/>
           <ProductSkeletonBox/>
           <ProductSkeletonBox/>
           <ProductSkeletonBox/>
           <ProductSkeletonBox/>
           <ProductSkeletonBox/>
           <ProductSkeletonBox/>
        </div>
    )
}
