import MyCarousel from "./carousal"
import ShowCard from "./Cards"
import Jumbotron from './Jumbotron';
import Accordian from './Accordian'
import GridCard from './gridCard'
import Footer from './Footer';



function HomePage()
{
    return(
        <div>
        <MyCarousel  />
    
     <Jumbotron />
      <Accordian></Accordian> 
     <GridCard></GridCard>
     <ShowCard />
    
     </div> 
    )
}

export default HomePage;