export const API_BASE_URL = 'http://localhost:4000';
export const ACCESS_TOKEN_NAME = 'login_access_token';
export const USER_DATA = 'user_data';