import React from 'react'
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import HomeIcon from '@material-ui/icons/Home';
import { Link } from "react-router-dom";
import { makeStyles } from '@material-ui/core';


const useStyles = makeStyles(() => ({
    wrapper:{
        marginTop:200,
        textAlign:"center"
    }
  }));

export default function PageNotFound() {
    const classes = useStyles();
    return (
        <div className={classes.wrapper}>
            <Typography  variant="h2" gutterBottom color="textPrimary">404 Page Not Found</Typography>
               <Link to={"/"} className="btn-link">
                    <Button size="small" variant="contained"
                        color="secondary"
                        startIcon={<HomeIcon />}>
                        Home</Button>
                </Link>
        </div>
    )
}
