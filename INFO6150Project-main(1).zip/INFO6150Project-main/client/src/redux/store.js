import { createStore, combineReducers, applyMiddleware } from 'redux';
import rootReducer from './rootReducer';
import { composeWithDevTools } from 'redux-devtools-extension';
import thunk from 'redux-thunk';

const middleware = [thunk];
const cartFromLocalStorage = localStorage.getItem('cart') ? JSON.parse(localStorage.getItem('cart')) : [];

const INITIAL_STAGE = {
    cart: {
        cartItems: cartFromLocalStorage
    }
}
const store = createStore(rootReducer, INITIAL_STAGE, composeWithDevTools(applyMiddleware(...middleware)));




export default store;