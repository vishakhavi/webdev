import {
    AppBar,
    Toolbar,
    makeStyles,
    Button,
    IconButton,
  } from "@material-ui/core";
  import React from "react";
  import Tooltip from '@material-ui/core/Tooltip';
import SwitchVideoIcon from '@material-ui/icons/SwitchVideo';
import AccessibilityNewIcon from '@material-ui/icons/AccessibilityNew';
import FitnessCenterIcon from '@material-ui/icons/FitnessCenter';
import LocalDiningIcon from '@material-ui/icons/LocalDining'
import LocalGroceryStoreIcon from '@material-ui/icons/LocalGroceryStore';
import logo1 from '../images/Logo.png';
import PersonOutlineIcon from '@material-ui/icons/PersonOutline';
import Redorder from '@material-ui/icons/Reorder';
import Cart from './Cart/Cart';
import LocalMallIcon from '@material-ui/icons/LocalMall';
import HomeIcon from '@material-ui/icons/Home';
import {API_BASE_URL, ACCESS_TOKEN_NAME,USER_DATA} from '../constants/apiContants';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import Typography from '@material-ui/core/Typography';
import {useState, useEffect} from 'react';
import {
  withRouter,
  Link,
  NavLink
} from "react-router-dom";



  const useStyles = makeStyles(() => ({
    header: {
      backgroundColor: "Black",
      paddingRight: "70px",
      paddingLeft: "118px",
      "@media (max-width: 900px)": {
        paddingLeft: 0,
      },
    },
    logo: {
       // alignItems: 'left',
        height: 120,
        position: 'absolute',
        left: -90,
        marginRight: 500
    },
    menuButton: {
        alignItems: 'center',
        justifyContent: 'left',
        backgroundColor: 'black',
        paddingLeft: 350,
        margin: 0,
        textAlign: 'center',
        position: 'inline',
        width: 20



    },
    toolbar: {
      display: "flex",
      justifyContent: "space-between",
      maxWidth: 20
    },
    drawerContainer: {
      padding: "20px 30px",
    },
  }));



   function Header() {
     useEffect(()=>{
       getName();
     });

       const [name,setName] = useState(null);

      const getName = () =>{
        if(localStorage.getItem("user_data") != undefined){
          let userdata = JSON.parse(localStorage.getItem("user_data"));
          setName(userdata.name);
        }
      }


    const { header, logo, menuButton, toolbar, drawerContainer } = useStyles();
  
    const displayDesktop = () => {
      return (
        <Toolbar className={toolbar}>
            {<img src={logo1} className={logo} />} 
          <div>{getMenuButtons()}</div>
        </Toolbar>
      );
    };
  
    const logout = () => {
      localStorage.clear();
      window.location.href = '/';
    }
  
    const getMenuButtons = () => {
      console.log(name);

      if(name == null){
        console.log("here");

      return (
          <div>  
          <Button
          className={menuButton}
          >
              <Tooltip title="Home">
              <IconButton  style={{ marginRight: '2em', color: 'white'}}  edge="end" color="inherit" aria-label="LocalDiningIcon">
              <NavLink className="navbar-item"  to="/" style={{color: 'white'}}>  <HomeIcon fontSize="large" /></NavLink>
          </IconButton>
          </Tooltip>

          <Tooltip title="Appointment">
            <IconButton style={{ marginRight: '2em', color: 'white'}}  edge="start" color="inherit" aria-label="AccessibilityNewIcon">
            <NavLink className="navbar-item"  to="/appointments" style={{color: 'white'}}>    <AccessibilityNewIcon fontSize="large" /> </NavLink>

            </IconButton>
          </Tooltip>

          <Tooltip title="Food">
          <Link  to={`/accessories/type/FOOD`} >
          <IconButton style={{ marginRight: '2em', color: 'white'}}  edge="start" color="inherit" aria-label="LocalDiningIcon">
          <LocalDiningIcon fontSize="large" />
          </IconButton>
          </Link>
          </Tooltip>

          <Tooltip title="Fitness">
          <Link  to={`/accessories/type/RUN`} >
          <IconButton style={{ marginRight: '2em', color: 'white'}}  edge="center" color="inherit" aria-label="FitnessCenterIcon">
          <FitnessCenterIcon fontSize="large" />
          </IconButton>
          </Link>

          </Tooltip>

          <IconButton style={{ marginRight: '2em', color: 'white'}}  edge="center" color="inherit" aria-label="FitnessCenterIcon">
          <NavLink className="navbar-item"  to="/accessories" style={{color: 'white'}}>    <LocalGroceryStoreIcon fontSize="large" /> </NavLink>

          </IconButton>

          <Tooltip title="Login">

          <IconButton style={{ marginLeft: '14em', color: 'white', alignContent: 'left'}}  edge="end" color="inherit" aria-label="FitnessCenterIcon">
          <NavLink className="navbar-item"  to="/login" style={{color: 'white'}}>  <PersonOutlineIcon fontSize="large" /></NavLink>
          </IconButton>

        </Tooltip>

          </Button>

          </div>
          );
      }
      else{
        console.log("here as well");
        return (
          <div>  
            <Button
            className={menuButton}
            >
                <Tooltip title="Home">
                <IconButton  style={{ marginRight: '2em', color: 'white'}}  edge="end" color="inherit" aria-label="HomeIcon">
                <NavLink className="navbar-item"  to="/" style={{color: 'white'}}>  <HomeIcon fontSize="large" /></NavLink>
          </IconButton>
          </Tooltip>
          
  
          <Tooltip title="Appointment">
          <IconButton style={{ marginRight: '2em', color: 'white'}}  edge="start" color="inherit" aria-label="AccessibilityNewIcon">
        <NavLink className="navbar-item"  to="/appointments" style={{color: 'white'}}>    <AccessibilityNewIcon fontSize="large" /> </NavLink>
  
          </IconButton>
          </Tooltip>

          <Tooltip title="Food">
          <Link  to={`/accessories/type/FOOD`} >
          <IconButton style={{ marginRight: '2em', color: 'white'}}  edge="start" color="inherit" aria-label="LocalDiningIcon">
          <LocalDiningIcon fontSize="large" />
          </IconButton>
          </Link>
          </Tooltip>
  
          <Tooltip title="Fitness">
          <Link  to={`/accessories/type/RUN`} >
          <IconButton style={{ marginRight: '2em', color: 'white'}}  edge="center" color="inherit" aria-label="FitnessCenterIcon">
        <FitnessCenterIcon fontSize="large" />
          </IconButton>
          </Link>
          
          </Tooltip> 
          <Tooltip title="Store">
            <IconButton style={{ marginRight: '2em', color: 'white'}}  edge="center" color="inherit" aria-label="FitnessCenterIcon">
            <NavLink className="navbar-item"  to="/accessories" style={{color: 'white'}}>    <LocalMallIcon fontSize="large" /> </NavLink>
  
            </IconButton>
            </Tooltip>

            {/* <Tooltip title="OrderHistory">
            <Link  to={`/history`} >
            <IconButton style={{ marginRight: '2em', color: 'white'}}  edge="center" color="inherit" aria-label="FitnessCenterIcon">
          <Redorder fontSize="large" />
            </IconButton>
            </Link>
            
            </Tooltip> */}

            <Cart/> 

            <Typography variant="h6" gutterBottom>
              {name}
            </Typography>
          
          <Tooltip title="Logout">
  
            <IconButton style={{ marginLeft: '10em', color: 'white', alignContent: 'left'}}  edge="end" color="inherit" aria-label="FitnessCenterIcon" onClick={logout}>
            <ExitToAppIcon fontSize="large" />
            </IconButton>
  
          </Tooltip>
  
            </Button>
            
            </div>
          );
      }

    };

    return (
      <header>
        <AppBar className={header}>
          { displayDesktop()}
        </AppBar>
        
      </header>
    );
  }

  export default withRouter(Header)
