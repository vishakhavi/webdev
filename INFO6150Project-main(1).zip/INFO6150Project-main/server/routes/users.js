var express = require('express');
var router = express.Router();
const auth = require("../middleware/auth");
const { check } = require("express-validator");

const user_controller = require('../controllers/user.controller');
const order_history = require('../lib/controllers/orderhistory.controller');

router.get('/test', user_controller.test);
router.post('/register', user_controller.user_create);
router.post('/login', user_controller.user_login);
router.get("/me", auth, user_controller.me);


router.post('/orders', order_history.addorders);
router.get('/orders/:_id', order_history.getorders);

module.exports = router;