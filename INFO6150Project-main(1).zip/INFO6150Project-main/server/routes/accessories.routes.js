module.exports = (app) => {

    const accessories = require('../controllers/accessories.controller.js');

    app.get('/', function(req, res, next) {
        res.send('accessories');
    });

    // Create a new Note
    // app.post('/accessories', accessories.create);

    // Retrieve all accessories
    app.get('/accessories', accessories.findAll);

    // Retrieve showcase accessories
    app.get('/accessories/type/:type', accessories.findByType);

    // Retrieve a single Note with noteId
    app.get('/accessories/:_id', accessories.findOne);

    // Update a Note with noteId
    // app.put('/accessories/:_id', accessories.update);

    // Delete a Note with noteId
    // app.delete('/accessories/:_id', accessories.delete);


}