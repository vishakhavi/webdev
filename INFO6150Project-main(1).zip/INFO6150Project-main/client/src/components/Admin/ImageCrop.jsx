import React, { Component } from 'react'
import CameraAltIcon from '@material-ui/icons/CameraAlt';

export default class ImageCrop extends Component {

    constructor(props){
        super(props);
        this.state= {
            src:"https://orsa.tech/wp-content/uploads/2018/07/dummy-placeholder-image-400x400.jpg",
            open:false
        }
    }


    onSelectFile = e => {
        if (e.target.files && e.target.files.length > 0) {
          const reader = new FileReader();
          reader.onload = (event) => {
            this.setState({...this.state, src: event.target.result});
            this.props.cropFile(this.state.src);
          };
          reader.readAsDataURL(e.target.files[0]);
        }

        
      };

    render() {
        return (
          <div> 
            <div className="image-box">
                <img src={this.state.src} alt=""/>
                <input type="file" id="file-upload" accept="image/*" onChange={this.onSelectFile} />
                <label for="file-upload" class="custom-file-upload"  ><CameraAltIcon/></label>
            </div>
          </div>
        )
    }
}
