const axios = require('axios');
const { DOMAIN_URL } = require('./constants');

function create() {

}


function GETALL(url, query) {
    // return axios.get(`${DOMAIN_URL}/${url}`, {
    //         headers: {
    //             'Access-Control-Allow-Origin': '*',
    //         }
    //     })
    //     .then(function(response) {
    //         // handle success
    //         console.log(response);
    //     })
    //     .catch(function(error) {
    //         // handle error
    //         console.log(error);
    //     })
    //     .then(function() {
    //         // always executed
    //     });
}

export default GETALL