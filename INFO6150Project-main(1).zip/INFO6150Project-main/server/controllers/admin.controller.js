const Accessories = require('../lib/models/accessories.model');
const User = require("../lib/models/User");
const Format = require('response-format');
const CONSTANTS = require('../lib/utils/constants');



exports.getDash = async(req, res) => {
    try {
        const p1 = Promise.resolve(User.countDocuments());
        const p2 = Promise.resolve(Accessories.countDocuments());
        const p3 = Promise.resolve(User.find().sort({ createdAt: 1 }));

        const data = await Promise.all([p1, p2, p3]);
        let users = data[2];

        let userArr = [];
        let useObj = {};
        users.forEach((el) => {
            if (el.createdAt) {
                let date = new Date(el.createdAt);
                let newDate = date.getDate() + " " + CONSTANTS.MONTHS_NAME[date.getMonth()];
                if (useObj.hasOwnProperty(newDate)) useObj[newDate] += 1;
                else useObj[newDate] = 1;
            }
        });

        for (const [key, value] of Object.entries(useObj)) {
            let o = {};
            o["x"] = key;
            o["y"] = value;
            userArr.push(o);
        }
        // res.send(Format.success("", obj));
        let result = { usersCount: data[0], productsCount: data[1], userDash: userArr };

        res.send(Format.success("", result));


    } catch (e) {
        console.log("====================Error occured ", e);
        res.status(500).send(Format.internalError([e.message]));
    }

}