import React from 'react'
import './OrderHistory.css';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import Divider from '@material-ui/core/Divider';
import Orders from '../Cart/Orders';
import axios from 'axios';
import {useEffect,useState} from 'react';

export default function OrdersHistory(props) {
    useEffect(()=>{
      getData();
    },[]);


    const [orders,setOrd] = useState([]);
    const [products,setProducts] = useState([]);


    const getData = () => {
        if(localStorage.getItem("user_data") != undefined){
          let userdata = JSON.parse(localStorage.getItem("user_data"));
          getOrders(userdata._id);
        }else{
          alert("Something went wrong");
        }
    }


    const getOrders = async(_id) => {
      let {data} = await axios.get(`/user/orders/${_id}`);
      let ord = data.orders;
      console.log(ord);
      setOrd(ord);
   
      
    }
  
    const getSubTotal = (el) => {
    return el.products.reduce((price,item)=> item.qty * (item?.price - (item?.price * item?.discount /100)) + price,0);
    }

    const history = true;

    const getSmallList = (el) => {
      
      <div>
        <p>asdasd</p>
      {el.products.map((ele)=>{
        <div>
          <p>{ele.title}</p>
            <div className="item-wrapper">
              <div className="image">
                  <img src={ele?.image} alt="products"/>
              </div>
              <div className="desc">
                  <div className="left-float">
                      <span className="title">{ele?.title}</span>
                      <span className="price">${ele?.price - (ele?.price * ele?.discount /100) || 0}</span>
                  </div>
                  {ele.qty}
              </div>
            </div>
            <div className="cart-price-desc">
              <p>Amount Paid <span>${getSubTotal(el).toFixed(2)}</span> </p>
            </div>
          </div>
        })}
      </div>

    }

    // const formattedDate = date.toLocaleString("en-GB", {
    //   day: "numeric",
    //   month: "short",
    //   year: "numeric",
    //   hour: "numeric",
    //   minute: "2-digit"
    // });

    // com

    const list = () => (
        <div className="cart-list">
          {orders.map((el) => (
            <div key={el}>
              {/* <h4>Date : {getDate(el)}</h4> */}
              {getSmallList(el)}
            </div>
            ))
          }
        </div>
      );

    return (
        <div className="wrapper">
            <div className="success-msg">
                <img src="/images/success.gif" alt="success"/>
                <h1>Order Completed</h1>
            </div>
            <div className="history-data">
                {list()}
            </div>
        </div>
    )
}
