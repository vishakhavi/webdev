module.exports = {
    DOMAIN_URL: 'http://localhost:3001',
    ACCESSORIES: 'accessories',
    TYPE: {
        'FOOD': 'FOOD',
        "WEAR": "WEAR",
        "GEAR": "GEAR"
    },

    STATUS: {
        'ACTIVE': 'ACTIVE',
        "INACTIVE": "INACTIVE",
        "PENDING": "PENDING"
    }
}