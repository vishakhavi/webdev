import React from 'react'
import './Orders.css'

const Orders = (props) => {

    return (
        <div className="item-wrapper">
            <div className="image">
                <img src={props?.image} alt=""/>
            </div>
            <div className="desc">
                <div className="left-float">
                    <span className="title">{props?.title}</span>
                    <span className="price">${props?.price - (props?.price * props?.discount /100) || 0}</span>
                    <span className="quantity">{props?.qty}</span>
                </div>
            </div>
        </div>
    )
}

export default Orders;
