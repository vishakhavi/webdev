import { combineReducers } from 'redux';
import { cartReducer } from './reducers/cartReducers';
import { getProductsReducer, getProductDetailsReducer, getProductsByTypeReducer } from './reducers/productReducers';


const rootReducer = combineReducers({
    cart: cartReducer,
    getProducts: getProductsReducer,
    getProductsByType: getProductsByTypeReducer,
    getProductDetails: getProductDetailsReducer
});

export default rootReducer;