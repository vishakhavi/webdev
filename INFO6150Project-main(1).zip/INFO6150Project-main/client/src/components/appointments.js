import { useTheme } from "@material-ui/core/styles";
import { ThemeProvider } from '@material-ui/styles';
import useMediaQuery from "@material-ui/core/useMediaQuery";
import { Typography, makeStyles } from '@material-ui/core';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Button from '@material-ui/core/Button';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardMedia from '@material-ui/core/CardMedia';
import { flexbox } from '@material-ui/system';
import "./appointments.css";
import diet_appointment from "../images/diet_appointment.jpeg"
import aerobics_appointment from "../images/aerobics_appointment.jpeg"
import exercises_appointment from "../images/exercises_appointment.jpeg"
import body_appointment from "../images/body_appointment.jpeg"
import { Height } from "@material-ui/icons";
import {
  BrowserRouter as Router,
  Switch,
  withRouter,
  Route,
  Link,
  NavLink
} from "react-router-dom";

const useStyles = makeStyles(theme => ({
  root: {
    maxWidth: 300,
    [theme.breakpoints.down("sm")] : {
    maxWidth: 400,
    Height: 200
    }
  },
  media: {
    height: 140
  }
}));
const Cards = (props) =>  {
  const classes = useStyles();
  const theme = useTheme();

 // const matches = useMediaQuery(theme.breakpoints.up("sm"));
  return (

    <Card className={classes.root}>
      <CardActionArea>
        <CardMedia
          className={classes.media}
          image={props.picture}
          title="Contemplative Reptile"
        />
        <CardContent>
          <Typography gutterBottom variant="h5" component="h2">
            {props.data_header}
          </Typography>
          <Typography variant="body2" color="textSecondary" component="p">
            {props.details}
          </Typography>
        </CardContent>
      </CardActionArea>

    </Card>
  );
}

const Appointments = () =>
{
  var divStyle = {
    fontFamily: "sans-serif",
    fontWeight: "bold",
    paddingBottom: 130,
    padding: 30,
    margin: 3,
    display: 'flex',
    flexDirection: 'row',
    flex: '4',
    height:500
};

  const matches = useMediaQuery('(min-width:600px)');
  const matches2 = useMediaQuery('(max-width:600px)');
  if(matches)
  {
  return(
    <div style={divStyle}>
      <NavLink className="navbar-item"  to="/diet_appointment" style={{color: 'white'}}>
        <Cards class="cardStyle" picture={diet_appointment} data_header="Diet Recipes" details="Learn to cook tasty and healthy food in minutes! Designed by out nutritionist, an easy to follow healthy diet."></Cards>
      </NavLink>
      <div style={{margin: 20, padding:10}}></div>
      <NavLink className="navbar-item"  to="/aerobics_appointment" style={{color: 'white'}}>
        <Cards class="cardStyle" picture={aerobics_appointment} data_header="Aerobics" details="We have certified trainers who can guide with proper and efficient techniques."></Cards>
      </NavLink>
      <div style={{margin: 20, padding:10}}></div>
      <NavLink className="navbar-item"  to="/exercises_appointment" style={{color: 'white'}}>
        <Cards class="cardStyle" picture={exercises_appointment} data_header="Home Exercises" details="Pick up on an easy-to-follow regime to get your best body fitness, right from home!"></Cards>
      </NavLink>
      <div style={{margin: 20, padding:10}}></div>
      <NavLink className="navbar-item"  to="/body_appointment" style={{color: 'white'}}>
        <Cards class="cardStyle" picture={body_appointment} data_header="Body Building" details="To keep you fit & healthy through a range of holistic offerings that include fitness"></Cards>
      </NavLink>
      </div>
  )
  } else {
    return(
      <div style={{padding: 10}}>
        <NavLink className="navbar-item"  to="/diet_appointment" style={{color: 'white'}}>
          <Cards class="cardStyle1" picture={diet_appointment} data_header="Dance Activity" details="Fun workout to dance your way into fitness that will boost your health and relieve stress."></Cards>
        </NavLink>
         <div style={{margin: 10, padding:3}}></div>
        <NavLink className="navbar-item"  to="/diet_appointment" style={{color: 'white'}}>
          <Cards class="cardStyle1" picture={aerobics_appointment} data_header="Need Assitant?" details="We have certified trainers who can guide with proper and efficient techniques."></Cards>
        </NavLink>
        <div style={{margin: 10, padding:3}}></div>
        <NavLink className="navbar-item"  to="/diet_appointment" style={{color: 'white'}}>
         <Cards class="cardStyle1" picture={exercises_appointment} data_header="Diet" details="Designed by out nutritionist, an easy to follow healthy diet"></Cards>
        </NavLink>
        <div style={{margin: 10, padding:3}}></div>
        <NavLink className="navbar-item"  to="/diet_appointment" style={{color: 'white'}}>
         <Cards class="cardStyle1" picture={body_appointment} data_header="Body Building" details="To keep you fit & healthy through a range of holistic offerings that include fitness"></Cards>
         <div style={{margin: 10, padding:3}}></div>
        </NavLink>
      </div>
    )
  }

}
export default Appointments;
