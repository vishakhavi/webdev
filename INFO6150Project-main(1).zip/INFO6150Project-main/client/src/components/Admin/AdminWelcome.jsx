import React, { useEffect, useState } from 'react'
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
import DashCards from './Dashboard/DashCards';
import PeopleIcon from '@material-ui/icons/People';
import UserChart from './Dashboard/UserChart';
import BubbleChart from '../Graphs/BubbleChart';
import axios from 'axios';
import {
    Link,
    useHistory
  } from "react-router-dom";

import './Admin.css';

const useStyles = makeStyles((theme) => ({
    root: {
      flexGrow: 1,
    },
    paper: {
      height: 140,
      width: 100,
    },
    control: {
      padding: theme.spacing(2),
    },
    icons:{
        fontSize: 100,
        position: "absolute",
        // textAlign:"right",
        right:10
        // color: "azure"
    },
    card:{
        position:"relative"
    }
  }));


export default function AdminWelcome() {
    const classes = useStyles();

    useEffect(()=>{
        getDashDetails();
    },[]);

    const [dashData, setDashData] = useState([]);

    const getDashDetails = async() => {
        let { data } = await axios.get(`/admin/dashboard`);
        data = data.data;
        setDashData(data);
        console.log(data);
    }

    const tData = [
        {x: "13 April", y: 1},
        {x: "15 April", y: 3},
        {x: "16 April", y: 0},
        {x: "23 April", y: 2}
    ]

    let userObj = {
        label: "Users Registered",
        data: dashData.userDash,
        borderColor: '#3FCFA1',
        backgroundColor: '#3F50B5',
    }

    let transactionObj = {
        label: "Transactions",
        data: tData,
        borderColor: 'rgba(255, 99, 132, 0.2)',
        backgroundColor: 'rgb(255, 99, 132)',
    }

    return (
        <div>
             <Grid container className={classes.root} spacing={2}>
                {/* <Grid item xs={12}> */}
                    <Grid item xs={12} lg={4}>
                        <Link className="link" exact to="/admin/users">
                            <DashCards  className={classes.card} backgroundColor="#E7F5FF" value={dashData.usersCount} title="Users"  icon={<PeopleIcon className={classes.icons}/>} />
                        </Link>
                    </Grid>
                    <Grid item xs={12} lg={4}>
                        <Link className="link" exact to="/admin/product">
                            <DashCards backgroundColor="#FEEFF3" value={dashData.productsCount} title="Products"/>
                        </Link>
                    </Grid>
                    <Grid item xs={12} lg={4}>
                        <DashCards  backgroundColor="#FFF8DD" value={6} title="Transactions"/>
                    </Grid>
                {/* </Grid> */}
                <Grid item xs={6}>
                    <Paper className={classes.control}>
                        <UserChart {...userObj} />
                    </Paper>
                </Grid>
                <Grid item xs={6}>
                    <Paper className={classes.control}>
                        <UserChart {...transactionObj} />
                    </Paper>
                </Grid>
            </Grid>
        </div>
    )
}
