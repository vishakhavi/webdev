import React, {  useEffect } from 'react'
import {
  BrowserRouter as Router,
  Link,
  withRouter
} from "react-router-dom";
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import AccessoriesCard from './AccessoriesCard';
import ProductSkeleton from './ProductSkeleton';
import {  useSelector, useDispatch } from 'react-redux';
import { getProducts as listProducts} from '../../redux/actions/productActions';

const CONSTANTS = require('../../utils/constants');


const AccessoriesShowCase = () => {

  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(listProducts())
  }, [dispatch]);

  const getProducts = useSelector((state) => state.getProducts);

  const {products, loading, error} = getProducts;
  console.log(loading);
  let showCaseData = [];

  const responsive = {
    superLargeDesktop: {
      breakpoint: { max: 4000, min: 3000 },
      items: 5
    },
    desktop: {
      breakpoint: { max: 3000, min: 1024 },
      items: 4
    },
    tablet: {
      breakpoint: { max: 1024, min: 464 },
      items: 4
    },
    mobile: {
      breakpoint: { max: 464, min: 0 },
      items: 2
    }
  };

  const setShowCaseData = () => {
    let obj = {}; 
    Object.keys(CONSTANTS.TYPE).forEach(el=>{
      obj[el] = [];
    })
    products.map((el) => {
      if(el.type){
        let arr = obj[el.type] || [];
        arr.push(el);
        obj[el.type] = arr;
      }
    });

    for (const [key, value] of Object.entries(obj)) {
      let cards = [];
      value.forEach(el=>{
        cards.push(<div className="" key={el?._id}><AccessoriesCard key={el?._id} payload={el}/></div>)
      });
      showCaseData.push(<div key={key} className="carasoul-wrapper">
      
      {value?.length > 0 ? <span className="cat-title">{key}</span>:''}
          
       {value.length > 3 ? 
        <Router>
          <Link  to={`/accessories/type/${key}`} >
          <div key={key}>
                <span className="view-link">View All</span>
          </div>
          </Link>
          </Router>:''
        }
        <Carousel responsive={responsive}>{cards}</Carousel></div>);
    }
    console.clear();
    return showCaseData;
  }
  
  return (
    <div>

      {loading ? (<ProductSkeleton/>) : error ? (<h1>Error</h1>):  
      setShowCaseData()
      }
    </div>
  )
}


export default withRouter(AccessoriesShowCase);